# WeaponEvolution
Paper 1.21.11 · Java 21 · Maven

Build: `gradle build` -> `build/libs/survival-day-counter-1.0.0.jar` -> put in `plugins/`.
SQLite driver is bundled with Paper, so nothing is shaded.

Every new player gets a plain Wooden Spear and a plain Mace. Each weapon evolves on its own:
Wooden -> Copper -> Iron -> Golden -> Diamond -> Netherite: kill a player of the SAME tier with that weapon (this only
unlocks the next tier), then claim it with `/evolve [spear|mace]`. Netherite -> Beast (the highest tier) comes only
from the ritual below.
Tiers are cumulative: a higher tier keeps every ability and passive of the lower ones.

| Tier | Both weapons | Spear (piercing) | Mace (smashing) |
|---|---|---|---|
| Wooden | nothing: no enchantments, no abilities, can't be enchanted | | |
| Copper | Speed I while held | | |
| Iron | | Piercing Thrust | Crushing Blow |
| Gold | | Gilded Mark | Concussion |
| Diamond | | Frost Skewer | Shockwave Slam |
| Netherite | | Infernal Impale | Magma Quake |
| Beast | | Beast Rend + Impaling Charge (Sneak + F) + Thunder Strike | Titan's Wrath + Beast Roar (Sneak + F) |

### Beast Spear: Thunder Strike
Hitting an enemy **player** with the Beast Spear calls down lightning at their location, with electric sparks and
thunder. It is visual only (no damage, no fire, no block or mob changes). The cooldown is **exactly 10 seconds**,
fixed in code, tracked separately for every player, starts only when the lightning really fires, and survives
relogging. The remaining time shows on the action bar while you hold the spear ("Lightning: 7.3s", then
"Lightning ready"). The Netherite Spear has no lightning.

### Death reset (spear)
When a player is **killed by another player**, their spear automatically goes back to **Wooden** (saved to SQLite
first; abilities are cleared and must be earned again, the kill counter stays, the old weapon id is retired).
Deaths from falls, lava, mobs etc. do nothing, and the mace is untouched. Turn it off with
`death-reset.spear-on-pvp-death: false`.

### Spear lifesteal
Netherite and Beast spears restore **8 hearts per valid PvP kill** (`lifesteal.spear.netherite` / `.beast`,
capped at your max health). A kill is valid under the same rules as evolution kills (own registered weapon,
kill-credit window, same-IP block, spawn-kill and pair cooldown). Each kill is saved to SQLite first
(`weapon_upgrades`, reason `LIFESTEAL`, plus the weapon's kill counter) and the hearts are given afterwards.

Mace smash abilities trigger on falling hits (fall distance above `settings.smash-min-fall`).
Beast Roar moved from the spear to the mace; the spear's Beast active is now Impaling Charge.

Everything is in `config.yml`: cooldowns, chances, damage, radii, durations, particles, sounds,
passives and per-tier enchantments, plus a global `damage-multiplier`.

## No crafting shortcut
No weapon above Wooden can be crafted: crafting table, Crafter and smithing table results for every higher spear
and mace are blocked.

## Special Ritual Beacon and the ritual (the only way to Beast)
**Beast is the highest tier (above Netherite)** and is earned only by completing a ritual - never by kills,
crafting or `/evolve`.

- **Craft the beacon** in a crafting table: a Heart on each of the 4 sides (top, bottom, left, right), your own
  Netherite Spear or Mace in the centre, corners empty. The weapon stays; 4 hearts are used (`ritual-beacon.heart-item`,
  default Heart of the Sea). A Crafter can't make it. Only this special beacon works; an ordinary beacon never starts a ritual.
- **Placing it starts a 10-minute ritual** (`ritual-beacon.duration-minutes`), one at a time, survival mode only,
  and you need a Netherite weapon.
- **Everyone sees it:** the coordinates are broadcast in chat (and again on join and every 2 minutes), a boss bar
  shows the coordinates and the time left, and a light beam marks the spot from far away.
- **It must stay safe for the whole 10 minutes.** If ANY player breaks the beacon, or an explosion, wither or piston
  removes it, the ritual is cancelled at once and nothing is earned. The block is checked again at the end.
- **Success after 10 minutes:** the placer's Netherite Spear and/or Mace become **Beast** (saved to SQLite first),
  and the Beast weapon(s) **drop at the beacon** in a lightning flash. Only the owner can pick them up and they never
  despawn; if one is ever lost it is re-issued at Beast on join. Rituals are saved, so a restart doesn't cancel them.

## Kills and upgrades
- The weapon that dealt the **last hit** gets the kill: spear kills upgrade only the spear, mace kills only the mace.
  Each player has separate progress per weapon, saved in SQLite (`weapon_progress`, plus a permanent
  `weapon_upgrades` log). Beast is final.
- **No automatic upgrade.** A valid kill only *unlocks* the next tier (`upgrade_unlocks` table); `/evolve` claims it.
- **Same-level kill is required.** The victim's weapon tier must equal yours (`evolution.require-same-level-victim`).
  A Diamond player killing a Gold player unlocks nothing; neither does killing a higher tier.
- The upgrade is written to the database first (compare-and-set), then the item is replaced with the new
  material, name, lore, enchantments and abilities, with a title, particles and sound.
- Anti-exploit: same-IP block, persistent pair cooldown (both directions), spawn-kill protection,
  per-weapon upgrade gap, creative/spectator ignored, weapons only evolve for their owner, and every evolution
  retires the old weapon id so duplicated old copies stop working. A background scan removes duplicate copies.

## Permanent progression (SQLite, `plugins/WeaponEvolution/players.db`)
Saved per player: spear and mace tier, kills, the unique id of each weapon, who owns it, and every ability
unlocked. Everything is written to the database *before* the item changes, and reloaded on join, so it survives
reconnects, crashes and restarts.

- **Plugin updates never reset data.** The file stays in the data folder, tables are only added to, the schema
  version is stored in the file, a timestamped backup (`players.db.bak-v<old>-<time>`) is written before any
  migration, and a database from a newer version (or one that can't be opened) makes the plugin stay off instead
  of creating an empty one. Never delete the `.bak` files you don't need to.
- **Lost weapon? It comes back by itself.** If the item is missing on join (crash before the world saved, broke,
  destroyed) it is re-issued at its saved tier. The old id is retired in the same transaction, so no old copy
  can ever be used again.
- **No admin commands.** There are none; nothing is configured or repaired by hand.

## Anti-duplication
Weapons are **soulbound**: an evolved weapon can only live in its owner's own inventory.
- *Storage:* can't be put in chests, ender chests, shulkers, barrels, hoppers, horses, minecarts, bundles,
  item frames, armor stands, allays, decorated pots or trade GUIs. Crafting table, anvil, enchanting table and
  grindstone still work (items there always come back). Smithing upgrades are blocked.
- *Dropping:* evolved weapons can't be dropped (Q, inventory click, outside-window click, creative mode). If one
  still becomes an item entity (another plugin, a failed save) it never despawns, can't be damaged, burned or
  blown up, and only its owner can pick it up.
- *Trading:* can't be dropped; only the owner can pick one up; mobs and hoppers never can.
- *Death:* weapons never drop. They are saved to the database before they leave the drops and returned on
  respawn (or at next join). With `keepInventory` nothing changes.
- *Everything else:* the database allows only one active weapon per player and weapon type; a replayed kill or
  restore is rejected; retired and duplicate ids are deleted by the background scan; a weapon found in a
  stranger's inventory is taken back and returned to its owner.
- Wooden weapons stay plain vanilla items with no id (progress lives in the database, so copying one gains nothing).

# Minecraft Survival Day Counter (Fabric, MC 1.21.11)
Client-side only. Requires Fabric Loader >= 0.18.1, Fabric API, Java 21.

## Build
Needs internet (Gradle downloads Minecraft + mappings). With Gradle 9.x installed:
    gradle wrapper --gradle-version latest
    ./gradlew build        (Windows: gradlew.bat build)
Jar: build/libs/survival-day-counter-1.0.0.jar -> put in .minecraft/mods with Fabric API.
If a dependency version is not found, update gradle.properties from https://fabricmc.net/develop

## Commands
/daycounter stats | toggle | position <topleft|topright|bottomleft|bottomright>
/daycounter offset <x> <y> | color <RRGGBB> | background
Data: .minecraft/config/survival_day_counter/{config.json,worlds.json}. World folders are never touched.

## Build without a PC (GitHub Actions)
Upload this folder to a new GitHub repo (include the hidden .github folder). Open Actions > build > Run workflow.
When it finishes, download the "survival-day-counter-jar" artifact. Use the jar WITHOUT "-sources" in its name.

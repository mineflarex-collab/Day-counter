package com.example.survivaldaycounter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Per-world highest day, stored OUTSIDE the world folder
 * (.minecraft/config/survival_day_counter/worlds.json). World data is never modified.
 */
public class WorldStats {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("survival_day_counter").resolve("worlds.json");

    private Map<String, Long> highest = new HashMap<>();

    public static WorldStats load() {
        WorldStats s = new WorldStats();
        try {
            if (Files.exists(FILE)) {
                try (Reader r = Files.newBufferedReader(FILE)) {
                    Map<String, Long> m = GSON.fromJson(r, new TypeToken<Map<String, Long>>() {}.getType());
                    if (m != null) s.highest = m;
                }
            }
        } catch (Exception e) {
            SurvivalDayCounterClient.LOGGER.warn("Could not read worlds.json", e);
        }
        return s;
    }

    /** Returns -1 if this world has never been seen. */
    public long get(String key) { return highest.getOrDefault(key, -1L); }

    public void put(String key, long day) { highest.put(key, day); }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Path tmp = FILE.resolveSibling("worlds.json.tmp");
            try (Writer w = Files.newBufferedWriter(tmp)) { GSON.toJson(highest, w); }
            Files.move(tmp, FILE, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            SurvivalDayCounterClient.LOGGER.warn("Could not save worlds.json", e);
        }
    }
}

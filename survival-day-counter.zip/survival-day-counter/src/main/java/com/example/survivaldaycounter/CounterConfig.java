package com.example.survivaldaycounter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** HUD settings, stored in .minecraft/config/survival_day_counter/config.json */
public class CounterConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("survival_day_counter").resolve("config.json");

    public boolean enabled = true;
    /** topleft, topright, bottomleft, bottomright */
    public String anchor = "topleft";
    public int offsetX = 6;
    public int offsetY = 6;
    /** RGB hex without alpha, e.g. FFFFFF */
    public String color = "FFFFFF";
    public boolean shadow = true;
    public boolean background = true;

    public int argb() {
        try { return 0xFF000000 | (Integer.parseInt(color, 16) & 0xFFFFFF); }
        catch (NumberFormatException e) { return 0xFFFFFFFF; }
    }

    public static CounterConfig load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader r = Files.newBufferedReader(FILE)) {
                    CounterConfig c = GSON.fromJson(r, CounterConfig.class);
                    if (c != null) return c;
                }
            }
        } catch (Exception e) {
            SurvivalDayCounterClient.LOGGER.warn("Could not read config, using defaults", e);
        }
        CounterConfig c = new CounterConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer w = Files.newBufferedWriter(FILE)) { GSON.toJson(this, w); }
        } catch (Exception e) {
            SurvivalDayCounterClient.LOGGER.warn("Could not save config", e);
        }
    }
}

package com.example.survivaldaycounter;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

public class SurvivalDayCounterClient implements ClientModInitializer {
    public static final String MOD_ID = "survivaldaycounter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final long[] MILESTONES = {10, 50, 100, 365, 1000};
    private static final long TICKS_PER_DAY = 24000L;

    private CounterConfig config;
    private WorldStats stats;
    private String worldKey = null;
    private long currentDay = 1;
    private long highestDay = 1;

    @Override
    public void onInitializeClient() {
        config = CounterConfig.load();
        stats = WorldStats.load();

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of(MOD_ID, "day_counter"), this::renderHud);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            worldKey = resolveWorldKey(client);
            long saved = stats.get(worldKey);
            highestDay = Math.max(saved, 1);
            currentDay = highestDay;
            if (saved < 0) { // first time this world is seen: adopt current day silently
                ClientWorld w = client.world;
                if (w != null) highestDay = currentDay = dayOf(w);
                stats.put(worldKey, highestDay);
                stats.save();
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            saveNow();
            worldKey = null;
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> { saveNow(); config.save(); });
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(buildCommand()));
    }

    private static long dayOf(ClientWorld world) {
        return Math.max(0, Math.floorDiv(world.getTimeOfDay(), TICKS_PER_DAY)) + 1;
    }

    private String resolveWorldKey(MinecraftClient client) {
        try {
            if (client.isInSingleplayer() && client.getServer() != null) {
                Object name = client.getServer().getSavePath(WorldSavePath.ROOT).normalize().getFileName();
                return "sp:" + name;
            }
            if (client.getCurrentServerEntry() != null) return "mp:" + client.getCurrentServerEntry().address;
        } catch (Exception e) {
            LOGGER.warn("Could not resolve world key", e);
        }
        return "mp:unknown";
    }

    private void tick(MinecraftClient client) {
        if (worldKey == null || client.world == null || client.player == null) return;
        if (client.world.getTime() % 20 != 0) return; // once per second is plenty
        long day = dayOf(client.world);
        currentDay = day;
        if (day > highestDay) {
            for (long m : MILESTONES) {
                if (m > highestDay && m <= day) announce(client, m);
            }
            highestDay = day;
            stats.put(worldKey, highestDay);
            stats.save();
        }
    }

    private void announce(MinecraftClient client, long m) {
        Text msg = Text.literal("Milestone! You have survived " + m + " days!").formatted(Formatting.GOLD, Formatting.BOLD);
        client.player.sendMessage(msg, true);
        client.inGameHud.getChatHud().addMessage(msg);
    }

    private void saveNow() {
        if (worldKey != null) { stats.put(worldKey, highestDay); stats.save(); }
    }

    private void renderHud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!config.enabled || worldKey == null || mc.options.hudHidden || mc.world == null) return;
        TextRenderer tr = mc.textRenderer;
        String text = "Day " + currentDay;
        int w = tr.getWidth(text), h = tr.fontHeight;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        int pad = 3;
        int x = config.anchor.contains("right") ? sw - w - config.offsetX : config.offsetX;
        int y = config.anchor.contains("bottom") ? sh - h - config.offsetY : config.offsetY;
        if (config.background) ctx.fill(x - pad, y - pad, x + w + pad, y + h + pad, 0x80000000);
        ctx.drawText(tr, text, x, y, config.argb(), config.shadow);
    }

    private com.mojang.brigadier.builder.LiteralArgumentBuilder<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> buildCommand() {
        var root = ClientCommandManager.literal("daycounter");
        root.then(ClientCommandManager.literal("stats").executes(ctx -> {
            ctx.getSource().sendFeedback(Text.literal("Current day: " + currentDay + " | Highest day: " + highestDay)
                    .formatted(Formatting.YELLOW));
            return 1;
        }));
        root.then(ClientCommandManager.literal("toggle").executes(ctx -> {
            config.enabled = !config.enabled; config.save();
            ctx.getSource().sendFeedback(Text.literal("Day counter " + (config.enabled ? "shown" : "hidden")));
            return 1;
        }));
        root.then(ClientCommandManager.literal("position")
                .then(ClientCommandManager.argument("anchor", StringArgumentType.word())
                        .suggests((c, b) -> {
                            for (String s : new String[]{"topleft", "topright", "bottomleft", "bottomright"}) b.suggest(s);
                            return b.buildFuture();
                        })
                        .executes(ctx -> {
                            String a = StringArgumentType.getString(ctx, "anchor").toLowerCase(Locale.ROOT);
                            if (!a.matches("(top|bottom)(left|right)")) {
                                ctx.getSource().sendError(Text.literal("Use topleft, topright, bottomleft or bottomright"));
                                return 0;
                            }
                            config.anchor = a; config.save();
                            return 1;
                        })));
        root.then(ClientCommandManager.literal("offset")
                .then(ClientCommandManager.argument("x", IntegerArgumentType.integer(0, 2000))
                        .then(ClientCommandManager.argument("y", IntegerArgumentType.integer(0, 2000))
                                .executes(ctx -> {
                                    config.offsetX = IntegerArgumentType.getInteger(ctx, "x");
                                    config.offsetY = IntegerArgumentType.getInteger(ctx, "y");
                                    config.save();
                                    return 1;
                                }))));
        root.then(ClientCommandManager.literal("color")
                .then(ClientCommandManager.argument("hex", StringArgumentType.word())
                        .executes(ctx -> {
                            String hex = StringArgumentType.getString(ctx, "hex").replace("#", "");
                            if (!hex.matches("[0-9a-fA-F]{6}")) {
                                ctx.getSource().sendError(Text.literal("Use a 6-digit hex color, e.g. /daycounter color FFAA00"));
                                return 0;
                            }
                            config.color = hex.toUpperCase(Locale.ROOT); config.save();
                            return 1;
                        })));
        root.then(ClientCommandManager.literal("background").executes(ctx -> {
            config.background = !config.background; config.save(); return 1;
        }));
        return root;
    }
}

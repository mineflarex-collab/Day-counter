package com.weaponevolution;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * SQLite storage. One shared connection; all access is synchronized (SQLite is single-writer anyway).
 *
 * <ul>
 *   <li>players: who already received the starting weapons</li>
 *   <li>weapon_progress: current tier, kills and active weapon id of each player's spear and mace</li>
 *   <li>weapons: registry of every weapon id ever issued (owner, type, tier, ACTIVE or RETIRED).
 *       A partial unique index allows only ONE active weapon per owner and type.</li>
 *   <li>unlocked_abilities: abilities a player has unlocked per weapon type (never removed)</li>
 *   <li>pending_returns: exact copies of weapons waiting to be handed back to their owner
 *       (death, full inventory, offline owner)</li>
 *   <li>weapon_upgrades: permanent log of every upgrade (kill, craft, restore)</li>
 *   <li>retired_weapons: ids of replaced weapons; copies of them are dead everywhere</li>
 * </ul>
 *
 * Updates never reset data: tables are only ever created or added to, the schema version is stored in
 * PRAGMA user_version, a timestamped backup of the file is written before any migration, and a database
 * written by a NEWER version of the plugin is refused instead of touched.
 */
public final class DatabaseManager {

    /** Current schema version. Version 0 = databases written by plugin versions up to 1.3. */
    static final int SCHEMA_VERSION = 4;

    /** A weapon waiting to be returned to its owner. */
    public record Pending(String weaponId, byte[] item) {}

    /** An active ritual. */
    public record RitualRow(long id, String world, int x, int y, int z, UUID placer, long startedAt, long endsAt) {}

    /** A registry row. type is null for tombstones of ids whose type is unknown. */
    public record WeaponRecord(UUID owner, WeaponType type, String state) {}

    private final File file;
    private final Logger log;
    private Connection connection;

    public DatabaseManager(File file, Logger log) {
        this.file = file;
        this.log = log;
    }

    // ------------------------------------------------------------------ startup and migration

    public synchronized void init() throws SQLException, ClassNotFoundException, IOException {
        Class.forName("org.sqlite.JDBC"); // bundled with Paper
        boolean existed = file.isFile() && file.length() > 0;
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA busy_timeout=5000");
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=FULL");
        }

        int version = userVersion();
        if (version > SCHEMA_VERSION) {
            throw new SQLException("The database was written by a newer WeaponEvolution (schema v" + version
                    + ", this build supports v" + SCHEMA_VERSION + "). Refusing to start so nothing is damaged.");
        }
        if (version < SCHEMA_VERSION) {
            if (existed) {
                backup(version);
            }
            migrate(version);
            log.info("Database schema is now v" + SCHEMA_VERSION + " (was v" + version + "). No player data was removed.");
        }
    }

    private int userVersion() throws SQLException {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA user_version")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /** Copies the database file next to itself before a migration. If this fails the plugin does not start. */
    private void backup(int fromVersion) throws SQLException, IOException {
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA wal_checkpoint(TRUNCATE)"); // fold the WAL into the main file first
        }
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
        File dest = new File(file.getParentFile(), file.getName() + ".bak-v" + fromVersion + "-" + stamp);
        Files.copy(file.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        log.info("Database backup written to " + dest.getName());
    }

    private void migrate(int from) throws SQLException {
        connection.setAutoCommit(false);
        try (Statement st = connection.createStatement()) {
            createTables(st);
            if (from < 2) {
                backfillV2(st);
            }
            st.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_weapons_one_active "
                    + "ON weapons (owner_uuid, weapon) WHERE state = 'ACTIVE'");
            st.execute("PRAGMA user_version = " + SCHEMA_VERSION);
            connection.commit();
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    private void createTables(Statement st) throws SQLException {
        st.execute("""
                CREATE TABLE IF NOT EXISTS players (
                    uuid TEXT PRIMARY KEY NOT NULL,
                    received_at INTEGER NOT NULL
                )
                """);
        // Legacy tables from versions 1.0 / 1.1, kept only so their kill counts can be carried over.
        st.execute("""
                CREATE TABLE IF NOT EXISTS spear_stats (
                    uuid TEXT PRIMARY KEY NOT NULL,
                    kills INTEGER NOT NULL DEFAULT 0
                )
                """);
        st.execute("""
                CREATE TABLE IF NOT EXISTS weapon_stats (
                    uuid TEXT NOT NULL,
                    weapon TEXT NOT NULL,
                    kills INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (uuid, weapon)
                )
                """);
        st.execute("""
                CREATE TABLE IF NOT EXISTS weapon_progress (
                    uuid TEXT NOT NULL,
                    weapon TEXT NOT NULL,
                    tier INTEGER NOT NULL DEFAULT 1,
                    kills INTEGER NOT NULL DEFAULT 0,
                    weapon_id TEXT,
                    updated_at INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (uuid, weapon)
                )
                """);
        st.execute("""
                CREATE TABLE IF NOT EXISTS weapon_upgrades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uuid TEXT NOT NULL,
                    weapon TEXT NOT NULL,
                    from_tier INTEGER NOT NULL,
                    to_tier INTEGER NOT NULL,
                    victim_uuid TEXT,
                    reason TEXT NOT NULL,
                    at INTEGER NOT NULL
                )
                """);
        st.execute("CREATE INDEX IF NOT EXISTS idx_upgrades_pair ON weapon_upgrades (uuid, victim_uuid, at)");
        st.execute("CREATE INDEX IF NOT EXISTS idx_upgrades_weapon ON weapon_upgrades (uuid, weapon, at)");
        st.execute("""
                CREATE TABLE IF NOT EXISTS retired_weapons (
                    weapon_id TEXT PRIMARY KEY NOT NULL,
                    retired_at INTEGER NOT NULL
                )
                """);
        // ---- added in schema v2
        st.execute("""
                CREATE TABLE IF NOT EXISTS weapons (
                    weapon_id TEXT PRIMARY KEY NOT NULL,
                    owner_uuid TEXT,
                    weapon TEXT NOT NULL,
                    tier INTEGER NOT NULL,
                    state TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    retired_at INTEGER
                )
                """);
        st.execute("CREATE INDEX IF NOT EXISTS idx_weapons_owner ON weapons (owner_uuid, weapon, state)");
        st.execute("""
                CREATE TABLE IF NOT EXISTS unlocked_abilities (
                    uuid TEXT NOT NULL,
                    weapon TEXT NOT NULL,
                    ability_id TEXT NOT NULL,
                    unlocked_at INTEGER NOT NULL,
                    PRIMARY KEY (uuid, weapon, ability_id)
                )
                """);
        st.execute("""
                CREATE TABLE IF NOT EXISTS pending_returns (
                    weapon_id TEXT PRIMARY KEY NOT NULL,
                    owner_uuid TEXT NOT NULL,
                    item BLOB NOT NULL,
                    created_at INTEGER NOT NULL
                )
                """);
        st.execute("CREATE INDEX IF NOT EXISTS idx_pending_owner ON pending_returns (owner_uuid)");
        // ---- added in schema v3: a same-level kill unlocks the next tier; /evolve then claims it
        st.execute("""
                CREATE TABLE IF NOT EXISTS upgrade_unlocks (
                    uuid TEXT NOT NULL,
                    weapon TEXT NOT NULL,
                    from_tier INTEGER NOT NULL,
                    victim_uuid TEXT,
                    unlocked_at INTEGER NOT NULL,
                    PRIMARY KEY (uuid, weapon)
                )
                """);
        // ---- added in schema v4: rituals started by placing a Special Ritual Beacon, and the credits they earn
        st.execute("""
                CREATE TABLE IF NOT EXISTS rituals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    world TEXT NOT NULL,
                    x INTEGER NOT NULL,
                    y INTEGER NOT NULL,
                    z INTEGER NOT NULL,
                    placer_uuid TEXT NOT NULL,
                    started_at INTEGER NOT NULL,
                    ends_at INTEGER NOT NULL
                )
                """);
        st.execute("""
                CREATE TABLE IF NOT EXISTS ritual_credits (
                    uuid TEXT PRIMARY KEY NOT NULL,
                    credits INTEGER NOT NULL DEFAULT 0
                )
                """);
    }

    /** Carries older data into the new tables. Only INSERT OR IGNORE: nothing existing is overwritten. */
    private void backfillV2(Statement st) throws SQLException {
        st.execute("INSERT OR IGNORE INTO weapon_progress (uuid, weapon, tier, kills, weapon_id, updated_at) "
                + "SELECT uuid, 'SPEAR', 1, kills, NULL, 0 FROM spear_stats");
        st.execute("INSERT OR IGNORE INTO weapon_progress (uuid, weapon, tier, kills, weapon_id, updated_at) "
                + "SELECT uuid, weapon, 1, kills, NULL, 0 FROM weapon_stats");
        // Retired ids first, so an id that is somehow in both places stays dead.
        st.execute("INSERT OR IGNORE INTO weapons (weapon_id, owner_uuid, weapon, tier, state, created_at, updated_at, retired_at) "
                + "SELECT weapon_id, NULL, 'UNKNOWN', 0, 'RETIRED', retired_at, retired_at, retired_at FROM retired_weapons");
        st.execute("INSERT OR IGNORE INTO weapons (weapon_id, owner_uuid, weapon, tier, state, created_at, updated_at, retired_at) "
                + "SELECT weapon_id, uuid, weapon, tier, 'ACTIVE', updated_at, updated_at, NULL "
                + "FROM weapon_progress WHERE weapon_id IS NOT NULL");
    }

    // ------------------------------------------------------------------ small helpers

    private int exec(String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                if (params[i] == null) ps.setNull(i + 1, Types.NULL);
                else ps.setObject(i + 1, params[i]);
            }
            return ps.executeUpdate();
        }
    }

    private String currentWeaponId(UUID uuid, WeaponType type) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT weapon_id FROM weapon_progress WHERE uuid = ? AND weapon = ?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    // ------------------------------------------------------------------ progress

    public synchronized Map<WeaponType, ProgressManager.Progress> loadProgress(UUID uuid) throws SQLException {
        Map<WeaponType, ProgressManager.Progress> out = new EnumMap<>(WeaponType.class);
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT weapon, tier, kills, weapon_id FROM weapon_progress WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    WeaponType type = WeaponType.parse(rs.getString(1));
                    Tier tier = Tier.fromLevel(rs.getInt(2));
                    if (type == null || tier == null) continue;
                    out.put(type, new ProgressManager.Progress(tier, rs.getInt(3), rs.getString(4)));
                }
            }
        }
        return out;
    }

    public synchronized Map<WeaponType, Set<String>> loadUnlocked(UUID uuid) throws SQLException {
        Map<WeaponType, Set<String>> out = new EnumMap<>(WeaponType.class);
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT weapon, ability_id FROM unlocked_abilities WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    WeaponType type = WeaponType.parse(rs.getString(1));
                    if (type == null) continue;
                    out.computeIfAbsent(type, k -> new HashSet<>()).add(rs.getString(2));
                }
            }
        }
        return out;
    }

    public synchronized Set<String> loadRetiredIds() throws SQLException {
        Set<String> out = new HashSet<>();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT weapon_id FROM retired_weapons")) {
            while (rs.next()) out.add(rs.getString(1));
        }
        return out;
    }

    /** Records abilities as unlocked. Existing rows are left alone; nothing is ever removed. */
    public synchronized void addUnlocked(UUID uuid, WeaponType type, Collection<String> abilityIds) throws SQLException {
        if (abilityIds == null || abilityIds.isEmpty()) return;
        connection.setAutoCommit(false);
        try {
            addUnlockedTx(uuid, type, abilityIds, System.currentTimeMillis());
            connection.commit();
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    private void addUnlockedTx(UUID uuid, WeaponType type, Collection<String> ids, long now) throws SQLException {
        if (ids == null) return;
        for (String id : ids) {
            exec("INSERT OR IGNORE INTO unlocked_abilities (uuid, weapon, ability_id, unlocked_at) VALUES (?, ?, ?, ?)",
                    uuid.toString(), type.name(), id, now);
        }
    }

    /**
     * Records one upgrade in a single transaction. The update only succeeds if the stored tier still equals
     * expectedTier (compare-and-set), so one kill can never be applied twice. The weapon that was active in the
     * database and the weapon the player held are both retired, the new weapon is registered as the only active
     * one, and the abilities it unlocks are saved.
     *
     * @param fromTier tier of the weapon that was replaced (differs from expectedTier only for legacy weapons)
     * @return true if the upgrade was saved, false if the stored tier had already changed
     */
    public synchronized boolean recordUpgrade(UUID uuid, WeaponType type, Tier expectedTier, Tier fromTier,
                                              Tier toTier, String oldWeaponId, String newWeaponId, UUID victim,
                                              String reason, boolean countKill,
                                              Collection<String> newAbilityIds, boolean needsRitualCredit)
            throws SQLException {
        long now = System.currentTimeMillis();
        connection.setAutoCommit(false);
        try {
            exec("INSERT OR IGNORE INTO weapon_progress (uuid, weapon, tier, kills, weapon_id, updated_at) "
                    + "VALUES (?, ?, 1, 0, NULL, ?)", uuid.toString(), type.name(), now);
            String registeredId = currentWeaponId(uuid, type);
            int changed = exec("UPDATE weapon_progress SET tier = ?, kills = kills + ?, weapon_id = ?, updated_at = ? "
                            + "WHERE uuid = ? AND weapon = ? AND tier = ?",
                    toTier.level(), countKill ? 1 : 0, newWeaponId, now, uuid.toString(), type.name(),
                    expectedTier.level());
            if (changed != 1) {
                connection.rollback();
                return false;
            }
            if ("CLAIM".equals(reason)) {
                // A kill never upgrades by itself: the claim needs an unlock saved for exactly this tier.
                int used = exec("DELETE FROM upgrade_unlocks WHERE uuid = ? AND weapon = ? AND from_tier = ?",
                        uuid.toString(), type.name(), fromTier.level());
                if (used != 1) {
                    connection.rollback();
                    return false;
                }
            } else {
                exec("DELETE FROM upgrade_unlocks WHERE uuid = ? AND weapon = ?", uuid.toString(), type.name());
            }
            if (needsRitualCredit) { // Netherite -> Beast: one completed ritual is used up in the same transaction
                int paid = exec("UPDATE ritual_credits SET credits = credits - 1 WHERE uuid = ? AND credits > 0",
                        uuid.toString());
                if (paid != 1) {
                    connection.rollback();
                    return false;
                }
            }
            logUpgrade(uuid, type, fromTier, toTier, victim, reason, now);
            retireTx(registeredId, now); // the old active weapon must be dead before the new one is registered
            retireTx(oldWeaponId, now);
            registerTx(newWeaponId, uuid, type, toTier, now);
            addUnlockedTx(uuid, type, newAbilityIds, now);
            connection.commit();
            return true;
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    /**
     * Replaces a LOST weapon with a fresh one at the same tier: the old id is retired (every old copy anywhere
     * becomes dead) and the new id becomes the only active weapon. Fails if the stored weapon id is no longer
     * oldWeaponId, so two restores can never both succeed.
     */
    public synchronized boolean reissue(UUID uuid, WeaponType type, Tier tier, String oldWeaponId,
                                        String newWeaponId) throws SQLException {
        long now = System.currentTimeMillis();
        connection.setAutoCommit(false);
        try {
            int changed = exec("UPDATE weapon_progress SET weapon_id = ?, updated_at = ? "
                            + "WHERE uuid = ? AND weapon = ? AND tier = ? AND weapon_id = ?",
                    newWeaponId, now, uuid.toString(), type.name(), tier.level(), oldWeaponId);
            if (changed != 1) {
                connection.rollback();
                return false;
            }
            logUpgrade(uuid, type, tier, tier, null, "RESTORE", now);
            retireTx(oldWeaponId, now);
            registerTx(newWeaponId, uuid, type, tier, now);
            connection.commit();
            return true;
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    private void logUpgrade(UUID uuid, WeaponType type, Tier from, Tier to, UUID victim, String reason, long now)
            throws SQLException {
        exec("INSERT INTO weapon_upgrades (uuid, weapon, from_tier, to_tier, victim_uuid, reason, at) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)",
                uuid.toString(), type.name(), from.level(), to.level(), victim == null ? null : victim.toString(),
                reason, now);
    }

    private void registerTx(String weaponId, UUID owner, WeaponType type, Tier tier, long now) throws SQLException {
        if (weaponId == null) return;
        exec("INSERT INTO weapons (weapon_id, owner_uuid, weapon, tier, state, created_at, updated_at, retired_at) "
                + "VALUES (?, ?, ?, ?, 'ACTIVE', ?, ?, NULL)", weaponId, owner.toString(), type.name(), tier.level(), now, now);
    }

    /** Marks an id dead everywhere and drops any waiting copy of it. Safe to call for unknown ids. */
    private void retireTx(String weaponId, long now) throws SQLException {
        if (weaponId == null) return;
        exec("INSERT OR IGNORE INTO retired_weapons (weapon_id, retired_at) VALUES (?, ?)", weaponId, now);
        exec("UPDATE weapons SET state = 'RETIRED', retired_at = ?, updated_at = ? "
                + "WHERE weapon_id = ? AND state <> 'RETIRED'", now, now, weaponId);
        exec("INSERT OR IGNORE INTO weapons (weapon_id, owner_uuid, weapon, tier, state, created_at, updated_at, retired_at) "
                + "VALUES (?, NULL, 'UNKNOWN', 0, 'RETIRED', ?, ?, ?)", weaponId, now, now, now);
        exec("DELETE FROM pending_returns WHERE weapon_id = ?", weaponId);
    }

    // ------------------------------------------------------------------ registry and pending returns

    public synchronized WeaponRecord findWeapon(String weaponId) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT owner_uuid, weapon, state FROM weapons WHERE weapon_id = ?")) {
            ps.setString(1, weaponId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                String owner = rs.getString(1);
                UUID ownerId = null;
                if (owner != null) {
                    try {
                        ownerId = UUID.fromString(owner);
                    } catch (IllegalArgumentException ignored) {
                    }
                }
                return new WeaponRecord(ownerId, WeaponType.parse(rs.getString(2)), rs.getString(3));
            }
        }
    }

    /** Saves an exact copy of an active weapon so it can be handed back to its owner later. */
    public synchronized void savePending(UUID owner, String weaponId, byte[] item) throws SQLException {
        exec("INSERT OR REPLACE INTO pending_returns (weapon_id, owner_uuid, item, created_at) VALUES (?, ?, ?, ?)",
                weaponId, owner.toString(), item, System.currentTimeMillis());
    }

    public synchronized List<Pending> loadPending(UUID owner) throws SQLException {
        List<Pending> out = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT weapon_id, item FROM pending_returns WHERE owner_uuid = ?")) {
            ps.setString(1, owner.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(new Pending(rs.getString(1), rs.getBytes(2)));
            }
        }
        return out;
    }

    public synchronized void deletePending(String weaponId) throws SQLException {
        exec("DELETE FROM pending_returns WHERE weapon_id = ?", weaponId);
    }

    // ------------------------------------------------------------------ anti-farming queries

    /** Time (ms) of the latest counted kill between two players, or 0. Symmetric also counts the reverse direction. */
    public synchronized long lastCountedKill(UUID killer, UUID victim, boolean symmetric) throws SQLException {
        return lastCountedKill(killer, victim, symmetric, false);
    }

    /**
     * Same as above; with includeLifesteal the kills that only paid out lifesteal (Netherite / Beast weapons,
     * reason LIFESTEAL) count as well, so they can't be farmed between two players either.
     */
    public synchronized long lastCountedKill(UUID killer, UUID victim, boolean symmetric, boolean includeLifesteal)
            throws SQLException {
        String reasons = includeLifesteal ? "reason IN ('KILL', 'LIFESTEAL')" : "reason = 'KILL'";
        String sql = "SELECT MAX(at) FROM weapon_upgrades WHERE " + reasons + " AND "
                + (symmetric
                ? "((uuid = ? AND victim_uuid = ?) OR (uuid = ? AND victim_uuid = ?))"
                : "(uuid = ? AND victim_uuid = ?)");
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, killer.toString());
            ps.setString(2, victim.toString());
            if (symmetric) {
                ps.setString(3, victim.toString());
                ps.setString(4, killer.toString());
            }
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0L;
            }
        }
    }

    /**
     * Saves one valid kill made with an already-evolved weapon (no tier change): a permanent log row, and the
     * weapon's kill counter when countKill is true. Fails (false) if the stored tier is no longer expectedTier.
     */
    public synchronized boolean recordKill(UUID uuid, WeaponType type, Tier expectedTier, UUID victim,
                                           boolean countKill) throws SQLException {
        long now = System.currentTimeMillis();
        connection.setAutoCommit(false);
        try {
            if (countKill) {
                int changed = exec("UPDATE weapon_progress SET kills = kills + 1, updated_at = ? "
                                + "WHERE uuid = ? AND weapon = ? AND tier = ?",
                        now, uuid.toString(), type.name(), expectedTier.level());
                if (changed != 1) {
                    connection.rollback();
                    return false;
                }
            }
            logUpgrade(uuid, type, expectedTier, expectedTier, victim, "LIFESTEAL", now);
            connection.commit();
            return true;
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    /**
     * Puts a weapon type back to Wooden (death reset): the tier drops to 1, the active weapon id is retired (every
     * copy becomes dead), the saved abilities of that type are cleared so they are earned again, and the reset is
     * logged. The kill counter is kept. Only succeeds if the stored tier is still expectedTier.
     */
    public synchronized boolean resetToWooden(UUID uuid, WeaponType type, Tier expectedTier) throws SQLException {
        long now = System.currentTimeMillis();
        connection.setAutoCommit(false);
        try {
            String registeredId = currentWeaponId(uuid, type);
            int changed = exec("UPDATE weapon_progress SET tier = 1, weapon_id = NULL, updated_at = ? "
                            + "WHERE uuid = ? AND weapon = ? AND tier = ?",
                    now, uuid.toString(), type.name(), expectedTier.level());
            if (changed != 1) {
                connection.rollback();
                return false;
            }
            retireTx(registeredId, now);
            exec("DELETE FROM unlocked_abilities WHERE uuid = ? AND weapon = ?", uuid.toString(), type.name());
            exec("DELETE FROM upgrade_unlocks WHERE uuid = ? AND weapon = ?", uuid.toString(), type.name());
            logUpgrade(uuid, type, expectedTier, Tier.WOODEN, null, "DEATH_RESET", now);
            connection.commit();
            return true;
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    /** The tier whose upgrade this player has unlocked (but not yet claimed) for a weapon type, or null. */
    public synchronized Tier pendingUnlock(UUID uuid, WeaponType type) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT from_tier FROM upgrade_unlocks WHERE uuid = ? AND weapon = ?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Tier.fromLevel(rs.getInt(1)) : null;
            }
        }
    }

    /**
     * Saves "the next tier is unlocked" after a valid same-level kill. The tier does NOT change here. Only
     * succeeds if the stored tier is still tier and nothing is unlocked yet. The kill is logged (reason KILL)
     * so the pair cooldown and the upgrade gap keep working.
     */
    public synchronized boolean recordUnlock(UUID uuid, WeaponType type, Tier tier, UUID victim) throws SQLException {
        long now = System.currentTimeMillis();
        connection.setAutoCommit(false);
        try {
            exec("INSERT OR IGNORE INTO weapon_progress (uuid, weapon, tier, kills, weapon_id, updated_at) "
                    + "VALUES (?, ?, 1, 0, NULL, ?)", uuid.toString(), type.name(), now);
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT tier FROM weapon_progress WHERE uuid = ? AND weapon = ?")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, type.name());
                try (ResultSet rs = ps.executeQuery()) {
                    // legacy (id-less) weapons may be ahead of the stored tier; they are adopted at claim time
                    if (!rs.next() || rs.getInt(1) > tier.level()) {
                        connection.rollback();
                        return false;
                    }
                }
            }
            int added = exec("INSERT OR IGNORE INTO upgrade_unlocks (uuid, weapon, from_tier, victim_uuid, unlocked_at) "
                    + "VALUES (?, ?, ?, ?, ?)", uuid.toString(), type.name(), tier.level(), victim.toString(), now);
            if (added != 1) {
                connection.rollback();
                return false;
            }
            logUpgrade(uuid, type, tier, tier, victim, "KILL", now);
            connection.commit();
            return true;
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    /** Time (ms) of the latest kill upgrade of this player's weapon type, or 0. */
    public synchronized long lastUpgrade(UUID uuid, WeaponType type) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT MAX(at) FROM weapon_upgrades WHERE uuid = ? AND weapon = ? AND reason = 'KILL'")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0L;
            }
        }
    }

    // ------------------------------------------------------------------ rituals

    public synchronized long startRitual(String world, int x, int y, int z, UUID placer, long startedAt, long endsAt)
            throws SQLException {
        exec("INSERT INTO rituals (world, x, y, z, placer_uuid, started_at, ends_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                world, x, y, z, placer.toString(), startedAt, endsAt);
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery("SELECT last_insert_rowid()")) {
            return rs.next() ? rs.getLong(1) : 0L;
        }
    }

    public synchronized List<RitualRow> loadRituals() throws SQLException {
        List<RitualRow> out = new ArrayList<>();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, world, x, y, z, placer_uuid, started_at, ends_at FROM rituals ORDER BY id")) {
            while (rs.next()) {
                try {
                    out.add(new RitualRow(rs.getLong(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
                            UUID.fromString(rs.getString(6)), rs.getLong(7), rs.getLong(8)));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        return out;
    }

    public synchronized void cancelRitual(long id) throws SQLException {
        exec("DELETE FROM rituals WHERE id = ?", id);
    }

    /** The ritual survived: it is removed and the placer earns one credit, in one transaction. */
    public synchronized void finishRitual(long id, UUID placer) throws SQLException {
        connection.setAutoCommit(false);
        try {
            exec("DELETE FROM rituals WHERE id = ?", id);
            exec("INSERT OR IGNORE INTO ritual_credits (uuid, credits) VALUES (?, 0)", placer.toString());
            exec("UPDATE ritual_credits SET credits = credits + 1 WHERE uuid = ?", placer.toString());
            connection.commit();
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    public synchronized int ritualCredits(UUID uuid) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT credits FROM ritual_credits WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ------------------------------------------------------------------ starting weapons

    /**
     * Atomically claims the starting weapons for this player.
     *
     * @return true if this call created the record (player has never received weapons),
     *         false if the player was already recorded.
     */
    public synchronized boolean claim(UUID uuid) throws SQLException {
        return exec("INSERT OR IGNORE INTO players (uuid, received_at) VALUES (?, ?)",
                uuid.toString(), System.currentTimeMillis()) == 1;
    }

    /** Removes a claim (used only if the player left before the items could be delivered). */
    public synchronized void unclaim(UUID uuid) throws SQLException {
        exec("DELETE FROM players WHERE uuid = ?", uuid.toString());
    }

    public synchronized void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                try (Statement st = connection.createStatement()) {
                    st.execute("PRAGMA wal_checkpoint(TRUNCATE)");
                } catch (SQLException ignored) {
                }
                connection.close();
            }
        } catch (SQLException ignored) {
        }
    }
}

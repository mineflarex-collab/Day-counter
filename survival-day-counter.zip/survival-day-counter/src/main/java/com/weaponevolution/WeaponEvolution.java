package com.weaponevolution;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public final class WeaponEvolution extends JavaPlugin {

    private DatabaseManager database;
    private RitualBeaconListener ritual;
    private RitualManager rituals;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        migrateLegacyConfig();
        // Merge keys added by newer versions into an existing config.yml.
        getConfig().options().copyDefaults(true);
        saveConfig();

        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().severe("Could not create plugin data folder.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // The database lives in the plugin's data folder and is never replaced by a plugin update.
        // If it cannot be opened or migrated the plugin stays off: it will not start a new, empty one.
        File dbFile = new File(getDataFolder(), getConfig().getString("database-file", "players.db"));
        try {
            database = new DatabaseManager(dbFile, getLogger());
            database.init();
        } catch (SQLException | ClassNotFoundException | IOException e) {
            getLogger().severe("Failed to open the player database (" + dbFile.getAbsolutePath() + "): " + e.getMessage());
            getLogger().severe("WeaponEvolution is disabled so no player data is touched.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        ProgressManager progress = new ProgressManager(this, database);
        try {
            progress.loadRetired();
        } catch (SQLException e) {
            getLogger().severe("Failed to load retired weapons: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        AbilityManager abilities = new AbilityManager(this);
        abilities.setProgress(progress);
        WeaponManager weapons = new WeaponManager(this, abilities, progress);
        AbilityListener abilityListener = new AbilityListener(this, weapons, abilities);
        RestoreService restore = new RestoreService(this, weapons, progress, database);

        getServer().getPluginManager().registerEvents(new JoinListener(this, database), this);
        getServer().getPluginManager().registerEvents(restore, this);
        getServer().getPluginManager().registerEvents(new WeaponGuardListener(weapons, progress), this);
        EvolutionListener evolution = new EvolutionListener(this, weapons, progress, database, abilities);
        getServer().getPluginManager().registerEvents(evolution, this);
        getServer().getPluginManager().registerEvents(new CraftGuardListener(), this);
        ritual = new RitualBeaconListener(this, weapons, progress);
        getServer().getPluginManager().registerEvents(ritual, this);
        ritual.registerRecipe();
        rituals = new RitualManager(this, database, ritual, weapons, progress, evolution);
        getServer().getPluginManager().registerEvents(rituals, this);
        rituals.restore();
        getServer().getPluginManager().registerEvents(abilityListener, this);
        getServer().getPluginManager().registerEvents(new EnchantGuardListener(this, weapons), this);
        org.bukkit.command.PluginCommand evolveCmd = getCommand("evolve");
        if (evolveCmd != null) {
            evolveCmd.setExecutor((sender, command, label, args) -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Only players can use /evolve.");
                    return true;
                }
                WeaponType type = args.length > 0 ? WeaponType.parse(args[0]) : null;
                if (type == null) {
                    type = WeaponType.of(p.getInventory().getItemInMainHand().getType());
                }
                if (type == null) {
                    p.sendMessage("Usage: /evolve <spear|mace> (or hold the weapon).");
                    return true;
                }
                evolution.claim(p, type);
                return true;
            });
            evolveCmd.setTabCompleter((sender, command, alias, args) ->
                    args.length == 1 ? java.util.List.of("spear", "mace") : java.util.List.of());
        }
        abilityListener.startPassiveTask();
        abilityListener.startThunderDisplayTask();

        // Players already online (after /reload): load their saved progress and restore their weapons.
        for (Player online : getServer().getOnlinePlayers()) {
            restore.load(online);
        }

        long scan = getConfig().getLong("evolution.integrity-scan-seconds", 10L);
        if (scan > 0) {
            new IntegrityTask(this, weapons, progress, restore).runTaskTimer(this, scan * 20L, scan * 20L);
        }

        getLogger().info("WeaponEvolution enabled. Player data: " + dbFile.getAbsolutePath());
    }

    /** Moves the old spear.* evolution settings (versions 1.0 / 1.1) to evolution.*. */
    private void migrateLegacyConfig() {
        if (!getConfig().isConfigurationSection("spear")) return;
        for (String key : new String[]{"kill-credit-seconds", "same-victim-cooldown-seconds",
                "block-same-ip", "announce-beast"}) {
            if (getConfig().isSet("spear." + key) && !getConfig().isSet("evolution." + key)) {
                getConfig().set("evolution." + key, getConfig().get("spear." + key));
            }
        }
        getConfig().set("spear", null); // also drops the obsolete spear.lifesteal / spear.ultimate sections
    }

    @Override
    public void onDisable() {
        if (ritual != null) {
            ritual.unregisterRecipe();
        }
        if (rituals != null) {
            rituals.shutdown();
        }
        if (database != null) {
            database.close();
        }
    }
}

package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.GameMode;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * Special Ritual Beacon: the item that starts the ritual which is required to turn a Netherite weapon into Beast
 * (placing it is handled by {@link RitualManager}).
 *
 * <p>Recipe (3x3 crafting table): a Heart on each of the 4 sides (top, bottom, left, right), the player's own
 * registered Netherite Spear (or Mace) in the centre, the 4 corners empty. The weapon in the centre is only
 * checked, never consumed: the craft takes the 4 hearts and gives the beacon.
 */
public final class RitualBeaconListener implements Listener {

    private static final int[] SIDES = {1, 3, 5, 7};

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;
    private final ProgressManager progress;
    private final NamespacedKey recipeKey;
    private final NamespacedKey itemKey;

    public RitualBeaconListener(WeaponEvolution plugin, WeaponManager weapons, ProgressManager progress) {
        this.plugin = plugin;
        this.weapons = weapons;
        this.progress = progress;
        this.recipeKey = new NamespacedKey(plugin, "ritual_beacon");
        this.itemKey = new NamespacedKey(plugin, "ritual_beacon_item");
    }

    // ------------------------------------------------------------------ the item

    public ItemStack createBeacon() {
        ItemStack item = new ItemStack(Material.BEACON);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Special Ritual Beacon", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Place it to start a 10-minute ritual for everyone to see.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Survive the ritual to earn your Beast upgrade.", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isBeacon(ItemStack item) {
        if (item == null || item.getType() != Material.BEACON) return false;
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    /** @return the inventory slot holding a Special Ritual Beacon, or -1. */
    public int findBeacon(PlayerInventory inv) {
        for (int i = 0; i < inv.getSize(); i++) {
            if (isBeacon(inv.getItem(i))) return i;
        }
        return -1;
    }

    /** Takes one beacon out of the given slot. */
    public void consumeOne(PlayerInventory inv, int slot) {
        ItemStack stack = inv.getItem(slot);
        if (!isBeacon(stack)) return;
        if (stack.getAmount() <= 1) inv.setItem(slot, null);
        else {
            stack.setAmount(stack.getAmount() - 1);
            inv.setItem(slot, stack);
        }
    }

    // ------------------------------------------------------------------ recipe

    public static Material heartMaterial(WeaponEvolution plugin) {
        String name = plugin.getConfig().getString("ritual-beacon.heart-item", "HEART_OF_THE_SEA");
        Material m = Material.matchMaterial(name == null ? "" : name);
        if (m == null || !m.isItem() || m.isAir()) {
            plugin.getLogger().warning("Invalid ritual-beacon.heart-item '" + name + "' - using HEART_OF_THE_SEA.");
            return Material.HEART_OF_THE_SEA;
        }
        return m;
    }

    /** Shape: " H " / "HXH" / " H " (H = heart, X = Netherite spear or mace). */
    public void registerRecipe() {
        unregisterRecipe();
        if (!plugin.getConfig().getBoolean("ritual-beacon.enabled", true)) return;
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, createBeacon());
        recipe.shape(" H ", "HXH", " H ");
        recipe.setIngredient('H', new RecipeChoice.MaterialChoice(heartMaterial(plugin)));
        recipe.setIngredient('X', new RecipeChoice.MaterialChoice(
                WeaponType.SPEAR.material(Tier.NETHERITE), WeaponType.MACE.material(Tier.NETHERITE)));
        plugin.getServer().addRecipe(recipe);
    }

    public void unregisterRecipe() {
        plugin.getServer().removeRecipe(recipeKey);
    }

    private boolean isRitual(Recipe recipe) {
        return recipe instanceof Keyed keyed && keyed.getKey().equals(recipeKey);
    }

    /** The centre item must be the player's own, registered Netherite weapon. */
    private boolean validCenter(Player p, ItemStack center) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return false;
        if (!progress.isLoaded(p.getUniqueId()) || center == null) return false;
        WeaponInfo w = weapons.getInfo(center);
        if (w == null || w.tier() != Tier.NETHERITE) return false;
        ProgressManager.Progress prog = progress.get(p.getUniqueId(), w.type());
        return prog != null && weapons.canEvolve(p, center, w, prog);
    }

    // ------------------------------------------------------------------ crafting

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepare(PrepareItemCraftEvent e) {
        if (!isRitual(e.getRecipe())) return;
        ItemStack[] m = e.getInventory().getMatrix();
        if (m.length < 9 || !(e.getView().getPlayer() instanceof Player p) || !validCenter(p, m[4])) {
            e.getInventory().setResult(null); // only your own Netherite weapon in the centre works
            return;
        }
        e.getInventory().setResult(createBeacon());
    }

    /** The craft is done by hand so the weapon in the centre is never consumed. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraft(CraftItemEvent e) {
        if (!isRitual(e.getRecipe())) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.isShiftClick()) {
            p.sendActionBar(Component.text("Pick the beacon up normally (no shift-click).", NamedTextColor.GRAY));
            return;
        }
        CraftingInventory inv = e.getInventory();
        ItemStack[] m = inv.getMatrix();
        if (m.length < 9 || !validCenter(p, m[4])) return;

        ItemStack cursor = p.getItemOnCursor();
        ItemStack beacon = createBeacon();
        ItemStack newCursor;
        if (cursor.getType().isAir()) {
            newCursor = beacon;
        } else if (cursor.isSimilar(beacon) && cursor.getAmount() < cursor.getMaxStackSize()) {
            newCursor = cursor.clone();
            newCursor.setAmount(cursor.getAmount() + 1);
        } else {
            p.sendActionBar(Component.text("Empty your cursor first.", NamedTextColor.GRAY));
            return;
        }
        for (int s : SIDES) {
            if (m[s] == null || m[s].getAmount() < 1) return;
        }
        for (int s : SIDES) { // 4 hearts are used up; the weapon in slot 4 stays
            ItemStack heart = m[s];
            heart.setAmount(heart.getAmount() - 1);
            m[s] = heart.getAmount() <= 0 ? null : heart;
        }
        inv.setMatrix(m);
        p.setItemOnCursor(newCursor);
        p.updateInventory();
        plugin.getLogger().info(p.getName() + " crafted a Special Ritual Beacon.");
    }

    /** A Crafter block could automate it, so it is blocked. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCrafter(CrafterCraftEvent e) {
        if (isRitual(e.getRecipe())) e.setCancelled(true);
    }

}

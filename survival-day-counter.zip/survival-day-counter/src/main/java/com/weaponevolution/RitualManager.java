package com.weaponevolution;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitTask;

import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The ritual. Placing a Special Ritual Beacon starts a 10-minute ritual at that block (one at a time).
 * Every player is told the coordinates (chat on start, on join and as a reminder), sees a boss bar with the
 * coordinates and the time left, and a light beam marks the spot from far away. Only the Special Ritual Beacon
 * (not an ordinary beacon) starts one. If ANY player (or an explosion, piston...) destroys the beacon before the
 * full time is up, the ritual is cancelled and nobody earns anything. If it survives all 10 minutes the ritual
 * succeeds: the placer's Netherite weapons become Beast (the highest tier) and the Beast weapons drop at the beacon.
 * Rituals are saved to SQLite and survive restarts.
 */
public final class RitualManager implements Listener {

    private record Active(long id, String world, int x, int y, int z, UUID placer, String placerName,
                          long startedAt, long endsAt) {
        boolean at(Block b) {
            return b.getX() == x && b.getY() == y && b.getZ() == z && b.getWorld().getName().equals(world);
        }
    }

    private final WeaponEvolution plugin;
    private final DatabaseManager database;
    private final RitualBeaconListener beacons;
    private final WeaponManager weapons;
    private final ProgressManager progress;
    private final EvolutionListener evolution;

    private Active active;
    private BossBar bar;
    private BukkitTask task;
    private long lastReminder;

    public RitualManager(WeaponEvolution plugin, DatabaseManager database, RitualBeaconListener beacons,
                         WeaponManager weapons, ProgressManager progress, EvolutionListener evolution) {
        this.plugin = plugin;
        this.database = database;
        this.beacons = beacons;
        this.weapons = weapons;
        this.progress = progress;
        this.evolution = evolution;
    }

    /** The weapon types of this player whose saved tier is Netherite (the ones a ritual turns into Beast). */
    private List<WeaponType> netheriteTypes(UUID uuid) throws SQLException {
        List<WeaponType> out = new ArrayList<>();
        for (Map.Entry<WeaponType, ProgressManager.Progress> en : database.loadProgress(uuid).entrySet()) {
            if (en.getValue().tier() == Tier.NETHERITE) out.add(en.getKey());
        }
        return out;
    }

    // ------------------------------------------------------------------ lifecycle

    /** Picks up a ritual that was running when the server stopped. */
    public void restore() {
        try {
            List<DatabaseManager.RitualRow> rows = database.loadRituals();
            for (DatabaseManager.RitualRow r : rows) {
                if (active != null) { // only one ritual at a time
                    database.cancelRitual(r.id());
                    continue;
                }
                active = new Active(r.id(), r.world(), r.x(), r.y(), r.z(), r.placer(),
                        nameOf(r.placer()), r.startedAt(), r.endsAt());
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Could not load the active ritual: " + e.getMessage());
        }
        if (active != null) startTask();
    }

    public void shutdown() {
        if (task != null) task.cancel();
        if (bar != null) Bukkit.getServer().hideBossBar(bar);
        task = null;
        bar = null;
    }

    private static String nameOf(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n != null ? n : "Unknown";
    }

    private long durationMs() {
        return Math.max(1L, plugin.getConfig().getLong("ritual-beacon.duration-minutes", 10L)) * 60_000L;
    }

    private void startTask() {
        lastReminder = System.currentTimeMillis();
        bar = BossBar.bossBar(Component.text("Ritual"), 0f, BossBar.Color.PURPLE, BossBar.Overlay.PROGRESS);
        Bukkit.getServer().showBossBar(bar);
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
        tick();
    }

    private String where(Active r) {
        return r.world() + " X: " + r.x() + " Y: " + r.y() + " Z: " + r.z();
    }

    // ------------------------------------------------------------------ placing

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!beacons.isBeacon(e.getItemInHand())) return; // an ordinary beacon never starts a ritual
        Player p = e.getPlayer();
        if (!plugin.getConfig().getBoolean("ritual-beacon.enabled", true)) {
            e.setCancelled(true);
            return;
        }
        if (active != null) {
            e.setCancelled(true);
            p.sendActionBar(Component.text("A ritual is already running at " + where(active) + ".", NamedTextColor.RED));
            return;
        }
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) {
            e.setCancelled(true);
            p.sendActionBar(Component.text("Rituals can't be started in creative mode.", NamedTextColor.GRAY));
            return;
        }
        try {
            if (netheriteTypes(p.getUniqueId()).isEmpty()) {
                e.setCancelled(true);
                p.sendActionBar(Component.text("You need a Netherite Spear or Mace for the ritual to turn into Beast.",
                        NamedTextColor.RED));
                return;
            }
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not read weapon progress: " + ex.getMessage());
            e.setCancelled(true);
            return;
        }
        Block b = e.getBlockPlaced();
        long now = System.currentTimeMillis();
        try {
            long id = database.startRitual(b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), p.getUniqueId(),
                    now, now + durationMs());
            active = new Active(id, b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), p.getUniqueId(),
                    p.getName(), now, now + durationMs());
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not save the ritual: " + ex.getMessage());
            e.setCancelled(true);
            return;
        }
        startTask();
        long minutes = durationMs() / 60_000L;
        Bukkit.getServer().sendMessage(Component.text("A RITUAL HAS BEGUN! ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(p.getName() + " placed a Special Ritual Beacon at " + where(active)
                        + ". It ends in " + minutes + " minutes - destroy the beacon to stop it!", NamedTextColor.YELLOW)));
        plugin.getLogger().info(p.getName() + " started a ritual at " + where(active));
    }

    // ------------------------------------------------------------------ progress

    private void tick() {
        Active r = active;
        if (r == null) return;
        long now = System.currentTimeMillis();
        World w = Bukkit.getWorld(r.world());
        boolean loaded = w != null && w.isChunkLoaded(r.x() >> 4, r.z() >> 4);

        if (loaded && w.getBlockAt(r.x(), r.y(), r.z()).getType() != Material.BEACON) {
            fail("The ritual beacon was destroyed - the ritual failed.");
            return;
        }
        long left = r.endsAt() - now;
        if (left <= 0) {
            if (w == null) {
                fail("The ritual world is gone - the ritual was cancelled.");
            } else {
                complete(r, w);
            }
            return;
        }

        float progress = (float) Math.min(1.0, Math.max(0.0, 1.0 - (double) left / (r.endsAt() - r.startedAt())));
        long sec = left / 1000L;
        bar.name(Component.text(String.format("Ritual at %s  %d:%02d left", where(r), sec / 60, sec % 60),
                NamedTextColor.LIGHT_PURPLE));
        bar.progress(progress);

        if (loaded) beam(w, r);

        long reminderMs = plugin.getConfig().getLong("ritual-beacon.reminder-seconds", 120L) * 1000L;
        if (reminderMs > 0 && now - lastReminder >= reminderMs) {
            lastReminder = now;
            Bukkit.getServer().sendMessage(Component.text("Ritual at " + where(r) + " - " + (sec / 60) + "m "
                    + (sec % 60) + "s left.", NamedTextColor.LIGHT_PURPLE));
        }
    }

    /** A light column above the beacon. Forced particles are drawn from far beyond normal particle range. */
    private void beam(World w, Active r) {
        int height = Math.max(8, plugin.getConfig().getInt("ritual-beacon.beam-height", 48));
        for (int i = 0; i < height; i += 2) {
            Location loc = new Location(w, r.x() + 0.5, r.y() + 1 + i, r.z() + 0.5);
            w.spawnParticle(Particle.END_ROD, loc, 1, 0.1, 0.0, 0.1, 0.0, null, true);
        }
        w.spawnParticle(Particle.PORTAL, new Location(w, r.x() + 0.5, r.y() + 1, r.z() + 0.5), 12, 0.6, 0.6, 0.6, 0.2,
                null, true);
    }

    /**
     * The ritual survived the full time: the placer's Netherite weapons (spear and/or mace) become Beast. Each
     * upgrade is saved to SQLite first (compare-and-set), then the Beast weapon drops at the beacon. The dropped
     * item is protected like every weapon (only its owner can pick it up, it never despawns); if it is ever lost
     * the weapon is re-issued at Beast on join.
     */
    private void complete(Active r, World w) {
        // The beacon must still be standing when the time is up (this loads the chunk if it was unloaded).
        if (w.getBlockAt(r.x(), r.y(), r.z()).getType() != Material.BEACON) {
            fail("The ritual beacon was destroyed - the ritual failed.");
            return;
        }
        UUID uid = r.placer();
        List<WeaponType> types;
        try {
            types = netheriteTypes(uid);
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not read weapon progress after the ritual: " + ex.getMessage());
            return; // try again next tick
        }

        Location drop = new Location(w, r.x() + 0.5, r.y() + 1.0, r.z() + 0.5);
        Player online = Bukkit.getPlayer(uid);
        boolean memory = online != null && progress.isLoaded(uid);
        List<String> made = new ArrayList<>();
        for (WeaponType type : types) {
            ProgressManager.Progress prog;
            try {
                prog = database.loadProgress(uid).get(type);
            } catch (SQLException ex) {
                plugin.getLogger().severe("Ritual: could not read progress: " + ex.getMessage());
                continue;
            }
            if (prog == null || prog.tier() != Tier.NETHERITE) continue;
            String newId = UUID.randomUUID().toString();
            try {
                boolean saved = database.recordUpgrade(uid, type, Tier.NETHERITE, Tier.NETHERITE, Tier.BEAST,
                        prog.weaponId(), newId, null, "RITUAL", false, weapons.abilityIds(type, Tier.BEAST), false);
                if (!saved) continue;
            } catch (SQLException ex) {
                plugin.getLogger().severe("Ritual: could not save the Beast upgrade: " + ex.getMessage());
                continue; // nothing saved, nothing changes
            }
            progress.retire(prog.weaponId());
            if (memory) {
                progress.addUnlocked(uid, type, weapons.abilityIds(type, Tier.BEAST));
                progress.set(uid, type, new ProgressManager.Progress(Tier.BEAST, prog.kills(), newId));
            }
            ItemStack beast = weapons.createItem(type, Tier.BEAST, null, uid, newId);
            Item dropped = w.dropItem(drop, beast);
            dropped.setOwner(uid);
            dropped.setUnlimitedLifetime(true);
            dropped.setInvulnerable(true);
            made.add(type.displayName());
            if (memory) evolution.playEvolution(online, type, Tier.NETHERITE, Tier.BEAST);
        }

        try {
            database.cancelRitual(r.id()); // the ritual is over; its row is removed
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not remove the finished ritual: " + ex.getMessage());
        }
        active = null;
        stopBar();
        w.getBlockAt(r.x(), r.y(), r.z()).setType(Material.AIR);
        w.strikeLightningEffect(drop);
        String what = made.isEmpty() ? "nothing" : "a Beast " + String.join(" and Beast ", made);
        Bukkit.getServer().sendMessage(Component.text("THE RITUAL IS COMPLETE! ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(r.placerName() + " earned " + what + " at " + where(r) + ".",
                        NamedTextColor.YELLOW)));
        if (online != null) {
            online.sendMessage(Component.text(made.isEmpty()
                    ? "The ritual is complete, but you had no Netherite weapon left to evolve."
                    : "Your Beast weapon dropped at the beacon - go and pick it up!", NamedTextColor.GREEN));
        }
        plugin.getLogger().info("Ritual by " + r.placerName() + " completed: " + made);
    }

    private void fail(String message) {
        Active r = active;
        if (r == null) return;
        try {
            database.cancelRitual(r.id());
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not cancel the ritual: " + ex.getMessage());
        }
        active = null;
        stopBar();
        Bukkit.getServer().sendMessage(Component.text(message, NamedTextColor.RED));
    }

    private void stopBar() {
        if (task != null) task.cancel();
        task = null;
        if (bar != null) Bukkit.getServer().hideBossBar(bar);
        bar = null;
    }

    // ------------------------------------------------------------------ everyone sees it

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (active == null) return;
        Player p = e.getPlayer();
        if (bar != null) p.showBossBar(bar);
        p.sendMessage(Component.text("A ritual is running at " + where(active) + " (started by "
                + active.placerName() + ").", NamedTextColor.LIGHT_PURPLE));
    }

    // ------------------------------------------------------------------ attacking the beacon

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (active == null || !active.at(e.getBlock())) return;
        e.setDropItems(false);
        fail(e.getPlayer().getName() + " destroyed the ritual beacon at " + where(active) + " - the ritual failed.");
    }

    /** Explosions are not blocked: if one takes the beacon, the ritual fails and no beacon item drops. */
    private void explosionCheck(List<Block> blocks, String cause) {
        if (active == null) return;
        for (java.util.Iterator<Block> it = blocks.iterator(); it.hasNext(); ) {
            Block b = it.next();
            if (!active.at(b)) continue;
            it.remove();
            b.setType(Material.AIR);
            fail("The ritual beacon at " + where(active) + " was destroyed by " + cause + " - the ritual failed.");
            return;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        explosionCheck(e.blockList(), "an explosion");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        explosionCheck(e.blockList(), "an explosion");
    }

    /** Anything else that changes the block (wither, enderman...) fails it too. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityChange(EntityChangeBlockEvent e) {
        if (active != null && active.at(e.getBlock())) {
            fail("The ritual beacon at " + where(active) + " was destroyed - the ritual failed.");
        }
    }

    /** A piston that moves the beacon takes it off its spot: the ritual fails. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (active != null && e.getBlocks().stream().anyMatch(active::at)) {
            fail("The ritual beacon was pushed away - the ritual failed.");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (active != null && e.getBlocks().stream().anyMatch(active::at)) {
            fail("The ritual beacon was pulled away - the ritual failed.");
        }
    }
}

package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.inventory.SmithItemEvent;
import org.bukkit.inventory.ItemStack;

import java.util.EnumSet;
import java.util.Set;

/**
 * Higher-tier spears and maces can only come from the kill progression (same-level kill, then /evolve).
 * Nothing above Wooden can be made in a crafting table, a Crafter or a smithing table, so there is no shortcut
 * around the progression. The plain Wooden Spear stays craftable: it carries no progress.
 */
public final class CraftGuardListener implements Listener {

    private final Set<Material> blocked = EnumSet.noneOf(Material.class);

    public CraftGuardListener() {
        for (WeaponType type : WeaponType.values()) {
            for (Tier tier : Tier.values()) {
                if (tier != Tier.WOODEN) blocked.add(type.material(tier));
            }
        }
        blocked.add(Material.MACE);
    }

    private boolean isBlocked(ItemStack item) {
        return item != null && blocked.contains(item.getType());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepare(PrepareItemCraftEvent e) {
        if (isBlocked(e.getInventory().getResult())) e.getInventory().setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraft(CraftItemEvent e) {
        if (isBlocked(e.getRecipe().getResult()) || isBlocked(e.getCurrentItem())) {
            e.setCancelled(true);
            if (e.getWhoClicked() instanceof Player p) {
                p.sendActionBar(Component.text("Higher weapons can't be crafted - earn them with same-level kills.",
                        NamedTextColor.GRAY));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCrafter(CrafterCraftEvent e) {
        if (isBlocked(e.getResult()) || isBlocked(e.getRecipe().getResult())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSmithingPrepare(PrepareSmithingEvent e) {
        if (isBlocked(e.getResult())) e.setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSmithing(SmithItemEvent e) {
        if (isBlocked(e.getCurrentItem())) e.setCancelled(true);
    }
}

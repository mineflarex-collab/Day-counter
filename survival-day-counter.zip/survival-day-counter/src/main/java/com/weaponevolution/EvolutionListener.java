package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import java.net.InetAddress;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Kill detection and evolution.
 *
 * <p>The weapon that dealt the last hit decides which weapon gets the kill (spear kills only affect the
 * spear, mace kills only the mace). A kill never upgrades anything by itself: killing a player of the SAME tier
 * unlocks the next tier, and /evolve claims it (one tier at a time). The unlock and the new tier are written
 * to SQLite first, and only then is the item replaced.
 */
public final class EvolutionListener implements Listener {

    /** @param tier tier of the attacker's own registered weapon at the time of the hit; null if it wasn't one
     *  @param victimTier tier of the victim's weapon of the same type at the time of the hit (their death reset
     *                   runs before the kill is processed, so it has to be read now); null if unknown */
    private record Hit(UUID attacker, WeaponType type, Tier tier, Tier victimTier, long time) {}

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;
    private final ProgressManager progress;
    private final DatabaseManager database;
    private final AbilityManager abilities;

    private final Map<UUID, Hit> lastHit = new HashMap<>();
    /** When each online player last joined or respawned (spawn-kill protection). */
    private final Map<UUID, Long> aliveSince = new HashMap<>();

    public EvolutionListener(WeaponEvolution plugin, WeaponManager weapons, ProgressManager progress,
                             DatabaseManager database, AbilityManager abilities) {
        this.plugin = plugin;
        this.weapons = weapons;
        this.progress = progress;
        this.database = database;
        this.abilities = abilities;
    }

    // ------------------------------------------------------------------ session tracking

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        aliveSince.put(id, System.currentTimeMillis()); // progress itself is loaded by RestoreService
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        aliveSince.put(e.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        lastHit.remove(id);
        aliveSince.remove(id);
        progress.unload(id);
    }

    // ------------------------------------------------------------------ which weapon dealt the hit

    /**
     * Remembers the weapon TYPE of the last hit on a player. Ability damage counts too, because it also comes
     * from the wielder. A hit with no custom weapon clears the credit, and a hit that dealt no damage
     * (blocked by a shield) does not steal it.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;
        if (!(e.getEntity() instanceof Player victim) || victim.equals(attacker)) return;
        if (e.getFinalDamage() <= 0) return;

        ItemStack held = attacker.getInventory().getItemInMainHand();
        WeaponInfo w = weapons.getInfo(held);
        if (w != null) {
            WeaponInfo own = weapons.getInfoFor(attacker, held); // null for copies and other players' weapons
            ProgressManager.Progress vp = progress.get(victim.getUniqueId(), w.type());
            lastHit.put(victim.getUniqueId(), new Hit(attacker.getUniqueId(), w.type(),
                    own != null ? own.tier() : null, vp != null ? vp.tier() : null, System.currentTimeMillis()));
        } else {
            lastHit.remove(victim.getUniqueId());
        }
    }

    // ------------------------------------------------------------------ the kill

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Hit hit = lastHit.remove(victim.getUniqueId()); // consumed: one death can only be processed once
        if (hit == null) return;

        FileConfiguration cfg = plugin.getConfig();
        long now = System.currentTimeMillis();
        if (now - hit.time() > cfg.getLong("evolution.kill-credit-seconds", 8L) * 1000L) return;

        Player killer = Bukkit.getPlayer(hit.attacker());
        if (killer == null || !killer.isOnline() || killer.equals(victim)) return;
        if (killer.hasMetadata("NPC") || victim.hasMetadata("NPC")) return;
        if (killer.getGameMode() == GameMode.CREATIVE || killer.getGameMode() == GameMode.SPECTATOR) return;
        if (!progress.isLoaded(killer.getUniqueId())) return; // progress not loaded yet: never guess

        lifesteal(killer, victim, hit, now); // before evolve(): its own record must not block the evolution
        unlockUpgrade(killer, victim, hit.type(), hit.victimTier(), now);
    }

    // ------------------------------------------------------------------ lifesteal on kill

    /**
     * Netherite and Beast spears restore hearts for every valid PvP kill (lifesteal.spear.<tier> in config.yml,
     * 8 hearts by default). A kill is valid under the same rules as an evolution kill: a real player victim,
     * killed with the killer's own registered weapon inside the kill-credit window, not between players on the
     * same IP, not a fresh spawn and not a repeat of the same pair inside the pair cooldown.
     * The kill is saved to SQLite first; the healing is applied afterwards.
     */
    private void lifesteal(Player killer, Player victim, Hit hit, long now) {
        if (hit.type() != WeaponType.SPEAR || hit.tier() == null || killer.isDead()) return;
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("lifesteal.enabled", true)) return;
        double hearts = cfg.getDouble("lifesteal.spear." + hit.tier().configKey(), 0.0);
        if (hearts <= 0) return; // only the tiers listed in config.yml (Netherite and Beast)

        UUID kid = killer.getUniqueId();
        ProgressManager.Progress prog = progress.get(kid, WeaponType.SPEAR);
        if (prog == null || prog.tier() != hit.tier()) return; // the weapon is not the registered one any more

        if (cfg.getBoolean("evolution.block-same-ip", true)) {
            InetAddress a = killer.getAddress() != null ? killer.getAddress().getAddress() : null;
            InetAddress b = victim.getAddress() != null ? victim.getAddress().getAddress() : null;
            if (a != null && a.equals(b)) return;
        }
        Long alive = aliveSince.get(victim.getUniqueId());
        long minAliveMs = cfg.getLong("evolution.min-victim-alive-seconds", 30L) * 1000L;
        if (alive != null && now - alive < minAliveMs) {
            rejectLater(killer, "No lifesteal - the victim only just spawned.");
            return;
        }

        try {
            long cooldownMs = cfg.getLong("evolution.same-victim-cooldown-seconds", 600L) * 1000L;
            if (cooldownMs > 0) {
                boolean symmetric = cfg.getBoolean("evolution.symmetric-pair-cooldown", true);
                long last = database.lastCountedKill(kid, victim.getUniqueId(), symmetric, true);
                if (last > 0 && now - last < cooldownMs) {
                    rejectLater(killer, "No lifesteal - you and this player killed each other too recently.");
                    return;
                }
            }
            if (!database.recordKill(kid, WeaponType.SPEAR, hit.tier(), victim.getUniqueId(), true)) return;
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not save lifesteal kill for " + killer.getName() + ": " + ex.getMessage());
            return; // nothing saved, no healing
        }
        progress.set(kid, WeaponType.SPEAR, new ProgressManager.Progress(prog.tier(), prog.kills() + 1, prog.weaponId()));

        double before = killer.getHealth();
        abilities.heal(killer, hearts * 2.0); // 1 heart = 2 health points; capped at the killer's max health
        double gained = (killer.getHealth() - before) / 2.0;
        UUID id = kid;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> { // after evolve()'s own action bar
            Player p = plugin.getServer().getPlayer(id);
            if (p != null && p.isOnline()) {
                p.sendActionBar(Component.text("Lifesteal: +" + formatHearts(gained) + " hearts", NamedTextColor.RED));
            }
        }, 2L);
    }

    private static String formatHearts(double hearts) {
        return hearts == Math.floor(hearts) ? String.valueOf((long) hearts) : String.format(java.util.Locale.ROOT, "%.1f", hearts);
    }

    private void rejectLater(Player killer, String text) {
        UUID id = killer.getUniqueId();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null && p.isOnline()) reject(p, text);
        }, 2L);
    }

    /** Finds this player's valid weapon of a type anywhere in the inventory; null if there is none. */
    private record Found(int slot, WeaponInfo info) {}

    private Found findWeapon(Player p, WeaponType type, ProgressManager.Progress prog) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            WeaponInfo w = weapons.getInfo(contents[i]);
            if (w == null || w.type() != type) continue;
            if (!weapons.canEvolve(p, contents[i], w, prog)) continue;
            return new Found(i, w);
        }
        return null;
    }

    /**
     * A valid kill never upgrades the weapon by itself. It only UNLOCKS the next tier, and only when the victim
     * is at the same level as the killer's weapon (a Diamond killing a Gold player unlocks nothing). The
     * unlock is saved to SQLite; the player then claims it with /evolve.
     */
    private void unlockUpgrade(Player killer, Player victim, WeaponType type, Tier victimTier, long now) {
        FileConfiguration cfg = plugin.getConfig();
        UUID kid = killer.getUniqueId();
        ProgressManager.Progress prog = progress.get(kid, type);
        if (prog == null) return;

        Found found = findWeapon(killer, type, prog);
        if (found == null) return;

        Tier from = found.info().tier();
        Tier next = from.next();
        if (next == null) return; // Beast is the final stage
        if (next == Tier.BEAST) { // Netherite -> Beast is never a kill upgrade: it comes from the ritual
            killer.sendActionBar(Component.text("Beast is earned through the ritual: craft a Special Ritual Beacon "
                    + "and defend it for the full time.", NamedTextColor.GOLD));
            return;
        }

        // Same-level rule: only a victim of the killer's own level unlocks the next tier.
        if (cfg.getBoolean("evolution.require-same-level-victim", true) && victimTier != from) {
            reject(killer, victimTier == null
                    ? "That kill doesn't count - the victim's level is unknown."
                    : "That kill doesn't count - kill a " + from.displayName() + " player to unlock "
                    + next.displayName() + " (you killed a " + victimTier.displayName() + " player).");
            return;
        }

        // Anti-farming checks.
        if (cfg.getBoolean("evolution.block-same-ip", true)) {
            InetAddress a = killer.getAddress() != null ? killer.getAddress().getAddress() : null;
            InetAddress b = victim.getAddress() != null ? victim.getAddress().getAddress() : null;
            if (a != null && a.equals(b)) return;
        }
        Long alive = aliveSince.get(victim.getUniqueId());
        long minAliveMs = cfg.getLong("evolution.min-victim-alive-seconds", 30L) * 1000L;
        if (alive != null && now - alive < minAliveMs) {
            reject(killer, "That kill doesn't count - the victim only just spawned.");
            return;
        }

        try {
            long cooldownMs = cfg.getLong("evolution.same-victim-cooldown-seconds", 600L) * 1000L;
            if (cooldownMs > 0) {
                boolean symmetric = cfg.getBoolean("evolution.symmetric-pair-cooldown", true);
                long last = database.lastCountedKill(kid, victim.getUniqueId(), symmetric);
                if (last > 0 && now - last < cooldownMs) {
                    reject(killer, "That kill doesn't count - you and this player killed each other too recently.");
                    return;
                }
            }
            long minGapMs = cfg.getLong("evolution.min-seconds-between-upgrades", 5L) * 1000L;
            if (minGapMs > 0) {
                long lastUp = database.lastUpgrade(kid, type);
                if (lastUp > 0 && now - lastUp < minGapMs) {
                    reject(killer, "That kill doesn't count - your " + type.displayName().toLowerCase()
                            + " just unlocked an upgrade.");
                    return;
                }
            }
            if (database.pendingUnlock(kid, type) == from) {
                killer.sendActionBar(Component.text("Your " + next.displayName() + " upgrade is already unlocked - use /evolve "
                        + type.configKey() + ".", NamedTextColor.GOLD));
                return;
            }
            // Save to SQLite first. Nothing about the weapon changes yet.
            if (!database.recordUnlock(kid, type, from, victim.getUniqueId())) return;
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not save upgrade unlock for " + killer.getName() + ": " + ex.getMessage());
            return;
        }

        killer.sendActionBar(Component.text("Upgrade unlocked: " + next.displayName() + " " + type.displayName()
                + " - type /evolve " + type.configKey() + " to claim it.", NamedTextColor.GREEN));
        killer.playSound(killer.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        plugin.getLogger().info(killer.getName() + " unlocked the " + next.displayName() + " " + type.displayName()
                + " upgrade (killed " + victim.getName() + ", " + (victimTier != null ? victimTier.displayName() : "unknown") + ").");
    }

    /** Netherite spear kills are already counted by the lifesteal save, so the claim must not count them twice. */
    private boolean killCountedByLifesteal(WeaponType type, Tier from) {
        return type == WeaponType.SPEAR && plugin.getConfig().getBoolean("lifesteal.enabled", true)
                && plugin.getConfig().getDouble("lifesteal.spear." + from.configKey(), 0.0) > 0;
    }

    /**
     * /evolve: applies an unlocked upgrade, exactly one tier. Needs a saved unlock for the weapon's current tier;
     * the unlock is consumed in the same database transaction that saves the new tier (compare-and-set).
     */
    public void claim(Player killer, WeaponType type) {
        FileConfiguration cfg = plugin.getConfig();
        UUID kid = killer.getUniqueId();
        ProgressManager.Progress prog = progress.get(kid, type);
        if (prog == null) {
            killer.sendMessage(Component.text("Your weapon progress is still loading - try again in a moment.", NamedTextColor.GRAY));
            return;
        }
        Found found = findWeapon(killer, type, prog);
        if (found == null) {
            killer.sendMessage(Component.text("You don't have a valid " + type.displayName().toLowerCase() + " to upgrade.", NamedTextColor.RED));
            return;
        }
        ItemStack[] contents = killer.getInventory().getContents();
        int slot = found.slot();
        Tier from = found.info().tier();
        Tier next = from.next();
        if (next == null) {
            killer.sendMessage(Component.text("Your " + type.displayName() + " is already Beast.", NamedTextColor.GRAY));
            return;
        }
        if (next == Tier.BEAST) {
            killer.sendMessage(Component.text("Netherite -> Beast can't be claimed: complete the ritual (craft and "
                    + "defend a Special Ritual Beacon).", NamedTextColor.GOLD));
            return;
        }

        String oldId = weapons.getWeaponId(contents[slot]); // null for plain Wooden and legacy weapons
        String newId = UUID.randomUUID().toString();
        try {
            if (database.pendingUnlock(kid, type) != from) {
                killer.sendMessage(Component.text("Not unlocked yet: kill a " + from.displayName()
                        + " player with your " + from.displayName() + " " + type.displayName() + " first.", NamedTextColor.RED));
                return;
            }
            boolean saved = database.recordUpgrade(kid, type, prog.tier(), from, next, oldId, newId,
                    null, "CLAIM", !killCountedByLifesteal(type, from), weapons.abilityIds(type, next), false);
            if (!saved) return;
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not save weapon upgrade for " + killer.getName() + ": " + ex.getMessage());
            return; // nothing was saved, so nothing changes
        }

        // Apply: update memory, retire the old weapon id, replace the item.
        progress.retire(oldId);
        progress.retire(prog.weaponId());
        progress.addUnlocked(kid, type, weapons.abilityIds(type, next));
        progress.set(kid, type, new ProgressManager.Progress(next, prog.kills() + 1, newId));
        ItemStack evolved = weapons.createItem(type, next, contents[slot], kid, newId);
        killer.getInventory().setItem(slot, evolved);
        if (slot == killer.getInventory().getHeldItemSlot()) {
            abilities.applyPassives(killer, new WeaponInfo(type, next)); // effects start immediately
        }

        playEvolution(killer, type, from, next);
        plugin.getLogger().info(killer.getName() + "'s " + type.displayName() + " evolved "
                + from.displayName() + " -> " + next.displayName() + " (claimed)");
    }

    private void reject(Player killer, String text) {
        killer.sendActionBar(Component.text(text, NamedTextColor.GRAY));
    }

    // ------------------------------------------------------------------ feedback

    public void playEvolution(Player p, WeaponType type, Tier from, Tier next) {
        FileConfiguration cfg = plugin.getConfig();
        Location loc = p.getLocation().add(0, 1, 0);
        World w = loc.getWorld();
        int level = next.level();

        if (cfg.getBoolean("evolution.effects.particles", true)) {
            w.spawnParticle(Particle.TOTEM_OF_UNDYING, loc, 20 + level * 8, 0.5, 0.8, 0.5, 0.3);
            w.spawnParticle(Particle.END_ROD, loc, 15 + level * 4, 0.6, 0.9, 0.6, 0.1);
            if (next.aura() != null) {
                w.spawnParticle(next.aura(), loc, 25 + level * 5, 0.6, 0.9, 0.6, 0.08);
            }
            if (next == Tier.BEAST) {
                w.spawnParticle(Particle.EXPLOSION, loc, 3, 0.5, 0.5, 0.5, 0);
            }
        }

        if (cfg.getBoolean("evolution.effects.sounds", true)) {
            float pitch = Math.min(2.0f, 0.7f + level * 0.1f); // every tier sounds higher than the last
            w.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1f, pitch);
            w.playSound(loc, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            if (next == Tier.BEAST) {
                w.playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.8f);
            }
        }

        if (cfg.getBoolean("evolution.effects.title", true)) {
            p.showTitle(Title.title(
                    Component.text(type.displayName().toUpperCase() + " EVOLVED", NamedTextColor.GOLD),
                    weapons.coloredName(type, next),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))));
        }

        if (cfg.getBoolean("evolution.effects.unlock-actionbar", true)) {
            List<String> unlocked = new ArrayList<>();
            List<String> before = abilities.unlocked(new WeaponInfo(type, from)).stream().map(Ability::name).toList();
            for (Ability a : abilities.unlocked(new WeaponInfo(type, next))) {
                if (!before.contains(a.name())) unlocked.add(a.name());
            }
            String passive = abilities.passiveSummary(type, next);
            if (!passive.isEmpty() && !passive.equals(abilities.passiveSummary(type, from))) {
                unlocked.add(passive + " (passive)");
            }
            if (!unlocked.isEmpty()) {
                p.sendActionBar(Component.text("Unlocked: " + String.join(", ", unlocked), NamedTextColor.YELLOW));
            }
        }

        if (next == Tier.BEAST && cfg.getBoolean("evolution.announce-beast", true)) {
            plugin.getServer().broadcast(Component.text(p.getName() + " has ascended to the ", NamedTextColor.RED)
                    .append(weapons.coloredName(type, next))
                    .append(Component.text("!", NamedTextColor.RED)));
        }
    }
}

package com.mineflarex.daycounter;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Counts the in-game days every player has survived since their last death and shows it on the action bar. */
public final class DayCounter extends JavaPlugin implements Listener, CommandExecutor {

    private static final long DAY = 24000L;

    private final Map<UUID, Long> start = new HashMap<>();
    private File dataFile;

    @Override
    public void onEnable() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
        if (data.isConfigurationSection("start")) {
            for (String key : data.getConfigurationSection("start").getKeys(false)) {
                try {
                    start.put(UUID.fromString(key), data.getLong("start." + key));
                } catch (IllegalArgumentException ignored) {
                    // bad key in data.yml: skip it
                }
            }
        }

        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("day") != null) getCommand("day").setExecutor(this);

        getServer().getScheduler().runTaskTimer(this, () -> {
            for (Player p : getServer().getOnlinePlayers()) {
                p.sendActionBar(Component.text("Day " + days(p) + " survived", NamedTextColor.GOLD));
            }
        }, 20L, 20L);
    }

    @Override
    public void onDisable() {
        save();
    }

    private World world() {
        return Bukkit.getWorlds().get(0);
    }

    /** Day number since the player's last death (first day = 1). */
    private long days(Player p) {
        long now = world().getFullTime();
        Long begin = start.get(p.getUniqueId());
        if (begin == null || now < begin) { // new player, or the time was set back
            begin = now;
            start.put(p.getUniqueId(), begin);
        }
        return (now - begin) / DAY + 1;
    }

    private void save() {
        YamlConfiguration data = new YamlConfiguration();
        start.forEach((id, time) -> data.set("start." + id, time));
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        days(e.getPlayer()); // registers a first-time player
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        save();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        start.put(e.getEntity().getUniqueId(), world().getFullTime());
        save();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        p.sendMessage(Component.text("You have survived " + days(p) + " day(s).", NamedTextColor.GOLD));
        return true;
    }
}

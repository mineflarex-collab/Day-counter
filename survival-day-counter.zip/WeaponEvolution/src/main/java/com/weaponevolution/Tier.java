package com.weaponevolution;

import org.bukkit.Particle;

import java.util.Locale;

/** The seven evolution tiers shared by every weapon type. */
public enum Tier {

    WOODEN(1, "Wooden", "#a0764a", null),
    COPPER(2, "Copper", "#b87333", Particle.ELECTRIC_SPARK),
    IRON(3, "Iron", "#c8c8c8", Particle.CRIT),
    GOLD(4, "Golden", "gold", Particle.WAX_ON),
    DIAMOND(5, "Diamond", "aqua", Particle.SNOWFLAKE),
    NETHERITE(6, "Netherite", "#9c6b8e", Particle.SOUL_FIRE_FLAME),
    BEAST(7, "Beast", "#ff2a2a", Particle.FLAME);

    private final int level;
    private final String displayName;
    private final String color;
    private final Particle aura;

    Tier(int level, String displayName, String color, Particle aura) {
        this.level = level;
        this.displayName = displayName;
        this.color = color;
        this.aura = aura;
    }

    public int level() { return level; }
    public String displayName() { return displayName; }
    public String color() { return color; }
    public Particle aura() { return aura; }

    /** Lower-case key used in config.yml (copper, gold, ...). */
    public String configKey() { return name().toLowerCase(Locale.ROOT); }

    public boolean atLeast(Tier other) { return level >= other.level; }

    /** @return the next tier, or null if this is Beast. */
    public Tier next() {
        Tier[] all = values();
        return ordinal() + 1 < all.length ? all[ordinal() + 1] : null;
    }

    public static Tier fromLevel(int level) {
        for (Tier t : values()) {
            if (t.level == level) return t;
        }
        return null;
    }

    /** Case-insensitive; accepts "golden" as an alias for GOLD. Returns null if unknown. */
    public static Tier parse(String s) {
        if (s == null) return null;
        String n = s.trim().toUpperCase(Locale.ROOT);
        if (n.equals("GOLDEN")) n = "GOLD";
        try {
            return valueOf(n);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}

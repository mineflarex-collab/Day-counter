package com.weaponevolution;

/** What an item is: a weapon type at a given evolution tier. */
public record WeaponInfo(WeaponType type, Tier tier) {
}

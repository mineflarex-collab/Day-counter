package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Creates and identifies evolution weapons (spears and maces), including their enchantments and lore. */
public final class WeaponManager {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final WeaponEvolution plugin;
    private final AbilityManager abilities;
    private final ProgressManager progress;
    private final NamespacedKey tierKey;
    /** Key used by version 1.0 spears; still read so existing items keep working. */
    private final NamespacedKey legacyKey;
    /** Unique id of one registered weapon. Replaced on every evolution; old ids are retired. */
    private final NamespacedKey idKey;
    private final NamespacedKey ownerKey;

    public WeaponManager(WeaponEvolution plugin, AbilityManager abilities, ProgressManager progress) {
        this.plugin = plugin;
        this.abilities = abilities;
        this.progress = progress;
        this.tierKey = new NamespacedKey(plugin, "weapon_tier");
        this.legacyKey = new NamespacedKey(plugin, "spear_stage");
        this.idKey = new NamespacedKey(plugin, "weapon_id");
        this.ownerKey = new NamespacedKey(plugin, "weapon_owner");
    }

    /** @return the item's registered weapon id, or null (plain Wooden weapons and pre-1.2 weapons have none). */
    public String getWeaponId(ItemStack item) {
        return readString(item, idKey);
    }

    /** Ids of the abilities a weapon of this type has unlocked at this tier (cumulative). */
    public List<String> abilityIds(WeaponType type, Tier tier) {
        return abilities.unlocked(new WeaponInfo(type, tier)).stream().map(Ability::id).toList();
    }

    /**
     * Like {@link #getInfo} but for a specific wielder: the weapon must belong to them and, if it carries an id,
     * be the one the database has registered as their active weapon. A copy, a retired weapon or someone else's
     * weapon gets no abilities and no passives.
     */
    public WeaponInfo getInfoFor(Player player, ItemStack item) {
        WeaponInfo info = getInfo(item);
        if (info == null) return null;
        UUID owner = getOwner(item);
        if (owner != null && !owner.equals(player.getUniqueId())) return null;
        String id = getWeaponId(item);
        if (id != null) {
            ProgressManager.Progress prog = progress.get(player.getUniqueId(), info.type());
            if (prog == null || !id.equals(prog.weaponId())) return null;
        }
        return info;
    }

    /** @return the player the weapon was issued to, or null. */
    public UUID getOwner(ItemStack item) {
        String raw = readString(item, ownerKey);
        if (raw == null) return null;
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private String readString(ItemStack item, NamespacedKey key) {
        if (item == null || item.getType() == Material.AIR || WeaponType.of(item.getType()) == null) return null;
        ItemMeta meta = item.getItemMeta();
        return meta == null ? null : meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    /**
     * @return what the item is, or null if it is not an evolution weapon.
     * A plain untagged Wooden Spear or Mace is the Wooden tier (the starting weapons stay completely vanilla).
     * Weapons whose id was retired (replaced by an evolution, restore or admin give) are dead copies: null.
     */
    public WeaponInfo getInfo(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return null;
        WeaponType type = WeaponType.of(item.getType());
        if (type == null) return null;

        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            Integer level = pdc.get(tierKey, PersistentDataType.INTEGER);
            if (level == null) level = pdc.get(legacyKey, PersistentDataType.INTEGER);
            if (level != null) {
                Tier tier = Tier.fromLevel(level);
                if (tier == null || type.material(tier) != item.getType()) return null;
                String id = pdc.get(idKey, PersistentDataType.STRING);
                if (id == null) {
                    // Pre-1.2 weapon without an id: only usable while legacy adoption is enabled.
                    if (!plugin.getConfig().getBoolean("evolution.adopt-legacy-weapons", true)) return null;
                } else if (progress.isRetired(id)) {
                    return null;
                }
                return new WeaponInfo(type, tier);
            }
        }
        boolean plainStarter = item.getType() == Material.WOODEN_SPEAR || item.getType() == Material.MACE;
        return plainStarter ? new WeaponInfo(type, Tier.WOODEN) : null;
    }

    /**
     * Builds a weapon. Wooden weapons are plain vanilla items (no enchantments, no abilities).
     *
     * @param previous the weapon being evolved; its enchantments are kept if settings.keep-old-enchantments
     *                 is true (the higher level wins). May be null.
     * @param owner    player the weapon is issued to (stored on the item); may be null
     * @param weaponId unique id registered in the database for this weapon; may be null
     */
    public ItemStack createItem(WeaponType type, Tier tier, ItemStack previous, UUID owner, String weaponId) {
        ItemStack item = new ItemStack(type.material(tier), 1);
        if (tier == Tier.WOODEN) return item;

        ItemMeta meta = item.getItemMeta();
        meta.displayName(coloredName(type, tier).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        meta.lore(buildLore(type, tier));

        Map<Enchantment, Integer> wanted = enchantsFor(type, tier);
        if (previous != null && plugin.getConfig().getBoolean("settings.keep-old-enchantments", true)) {
            previous.getEnchantments().forEach((en, lvl) -> wanted.merge(en, lvl, Math::max));
        }
        wanted.forEach((en, lvl) -> meta.addEnchant(en, lvl, true));

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(tierKey, PersistentDataType.INTEGER, tier.level());
        if (weaponId != null) pdc.set(idKey, PersistentDataType.STRING, weaponId);
        if (owner != null) pdc.set(ownerKey, PersistentDataType.STRING, owner.toString());
        if (tier.atLeast(Tier.NETHERITE)) {
            meta.setEnchantmentGlintOverride(true);
        }
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Rewrites an existing weapon's lore to the current layout (for example after an update added an ability,
     * so older Beast spears list Thunder Strike). Name, enchantments, id and owner are untouched.
     *
     * @return true if the lore changed
     */
    public boolean refreshLore(ItemStack item) {
        WeaponInfo info = getInfo(item);
        if (info == null || info.tier() == Tier.WOODEN) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        List<Component> wanted = buildLore(info.type(), info.tier());
        if (wanted.equals(meta.lore())) return false;
        meta.lore(wanted);
        item.setItemMeta(meta);
        return true;
    }

    /**
     * Whether this specific item may be evolved for this player:
     * it must belong to them and match their registered progress for this weapon type.
     */
    public boolean canEvolve(Player killer, ItemStack item, WeaponInfo w, ProgressManager.Progress prog) {
        UUID owner = getOwner(item);
        if (owner != null && !owner.equals(killer.getUniqueId())) return false; // someone else's weapon
        String id = getWeaponId(item);

        if (w.tier() == Tier.WOODEN) {
            return prog.tier() == Tier.WOODEN; // plain starter weapon: only while nothing was evolved yet
        }
        if (id == null) {
            // Pre-1.2 weapon: adopted only if it is ahead of the registered progress.
            return plugin.getConfig().getBoolean("evolution.adopt-legacy-weapons", true)
                    && w.tier().level() > prog.tier().level();
        }
        return id.equals(prog.weaponId()) && w.tier() == prog.tier();
    }

    public Component coloredName(WeaponType type, Tier tier) {
        return MM.deserialize("<" + tier.color() + "><bold>" + tier.displayName() + " " + type.displayName());
    }

    /** Enchantments configured for a weapon at a tier (enchantments.<type>.<tier>). Wooden never has any. */
    private Map<Enchantment, Integer> enchantsFor(WeaponType type, Tier tier) {
        Map<Enchantment, Integer> out = new LinkedHashMap<>();
        if (tier == Tier.WOODEN) return out;
        ConfigurationSection sec = plugin.getConfig()
                .getConfigurationSection("enchantments." + type.configKey() + "." + tier.configKey());
        if (sec == null) return out;
        for (String name : sec.getKeys(false)) {
            int level = sec.getInt(name, 0);
            if (level <= 0) continue;
            NamespacedKey nk = NamespacedKey.fromString(name.toLowerCase(Locale.ROOT));
            Enchantment en = nk == null ? null : Registry.ENCHANTMENT.get(nk);
            if (en == null) {
                plugin.getLogger().warning("Unknown enchantment '" + name + "' at enchantments."
                        + type.configKey() + "." + tier.configKey() + " - ignoring.");
                continue;
            }
            out.put(en, level);
        }
        return out;
    }

    private List<Component> buildLore(WeaponType type, Tier tier) {
        List<String> lines = new ArrayList<>();
        String c = "<" + tier.color() + ">";
        WeaponInfo info = new WeaponInfo(type, tier);

        lines.add("<gray>Stage " + tier.level() + " of " + Tier.values().length
                + (tier.next() == null ? " <red>(MAX)" : ""));
        lines.add("");

        String passive = abilities.passiveSummary(type, tier);
        if (!passive.isEmpty()) {
            lines.add(c + "Passive: <white>" + passive + " while held");
        }
        for (Ability a : abilities.unlocked(info)) {
            AbilitySettings s = abilities.settings(a);
            StringBuilder head = new StringBuilder(c + a.name() + " <dark_gray>[" + a.trigger().label() + "]");
            if (s.cooldownMs > 0) head.append(" <gray>").append(formatSeconds(s.cooldownMs)).append(" cooldown");
            lines.add(head.toString());
            lines.add("<gray> " + a.description());
        }

        double hearts = type == WeaponType.SPEAR && plugin.getConfig().getBoolean("lifesteal.enabled", true)
                ? plugin.getConfig().getDouble("lifesteal.spear." + tier.configKey(), 0.0) : 0.0;
        if (hearts > 0) {
            String shown = hearts == Math.floor(hearts) ? String.valueOf((long) hearts)
                    : String.format(Locale.ROOT, "%.1f", hearts);
            lines.add(c + "Lifesteal <dark_gray>[On Kill]");
            lines.add("<gray> Restores " + shown + " hearts for every valid PvP kill.");
        }

        lines.add("");
        if (tier.next() == null) {
            lines.add("<dark_red>The final form.");
        } else if (tier.next() == Tier.BEAST && plugin.getConfig().getBoolean("evolution.beast-requires-crafting", true)) {
            lines.add("<dark_gray>Craft with 8 " + BeastCraftListener.prettyName(BeastCraftListener.heartMaterial(plugin))
                    + " around it to reach Beast");
        } else {
            lines.add("<dark_gray>Evolves after 1 more PvP kill");
        }

        List<Component> lore = new ArrayList<>();
        for (String line : lines) {
            lore.add(line.isEmpty() ? Component.empty() : MM.deserialize("<!italic>" + line));
        }
        return lore;
    }

    private static String formatSeconds(long ms) {
        double sec = ms / 1000.0;
        return sec == Math.floor(sec) ? ((long) sec) + "s" : String.format(Locale.ROOT, "%.1fs", sec);
    }
}

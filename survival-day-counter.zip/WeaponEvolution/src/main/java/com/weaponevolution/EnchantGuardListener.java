package com.weaponevolution;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;

/** Wooden weapons can't be enchanted (table or anvil) while settings.wooden-block-enchanting is true. */
public final class EnchantGuardListener implements Listener {

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;

    public EnchantGuardListener(WeaponEvolution plugin, WeaponManager weapons) {
        this.plugin = plugin;
        this.weapons = weapons;
    }

    private boolean blocked(ItemStack item) {
        if (!plugin.getConfig().getBoolean("settings.wooden-block-enchanting", true)) return false;
        WeaponInfo info = weapons.getInfo(item);
        return info != null && info.tier() == Tier.WOODEN;
    }

    @EventHandler
    public void onPrepare(PrepareItemEnchantEvent e) {
        if (blocked(e.getItem())) e.setCancelled(true);
    }

    @EventHandler
    public void onEnchant(EnchantItemEvent e) {
        if (blocked(e.getItem())) e.setCancelled(true);
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        ItemStack first = e.getInventory().getFirstItem();
        ItemStack second = e.getInventory().getSecondItem();
        if (!blocked(first) || second == null) return;
        if (second.getType() == Material.ENCHANTED_BOOK || !second.getEnchantments().isEmpty()) {
            e.setResult(null);
        }
    }
}

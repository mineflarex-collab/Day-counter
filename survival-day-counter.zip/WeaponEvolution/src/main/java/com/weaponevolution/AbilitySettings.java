package com.weaponevolution;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;

/** Parsed config for one ability (abilities.<type>.<id>). */
public final class AbilitySettings {

    private final WeaponEvolution plugin;
    private final FileConfiguration cfg;
    private final String base;
    private final Map<String, Fx> extraFx = new HashMap<>();

    public final boolean enabled;
    public final Tier minTier;
    public final long cooldownMs;
    public final double chance;
    public final Fx fx;

    AbilitySettings(WeaponEvolution plugin, Ability ability) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
        this.base = "abilities." + ability.type().configKey() + "." + ability.id();

        this.enabled = cfg.getBoolean(base + ".enabled", true);
        Tier configured = Tier.parse(cfg.getString(base + ".min-tier"));
        Tier fixedTier = ability.fixedMinTier();
        this.minTier = fixedTier != null ? fixedTier : (configured != null ? configured : ability.defaultTier());
        long fixedCooldown = ability.fixedCooldownMs();
        this.cooldownMs = fixedCooldown >= 0 ? fixedCooldown
                : Math.max(0L, Math.round(cfg.getDouble(base + ".cooldown", 0.0) * 1000.0));
        this.chance = Math.max(0.0, Math.min(100.0, cfg.getDouble(base + ".chance", 100.0)));
        this.fx = Fx.load(plugin, cfg, base, "");
    }

    public double num(String key, double def) { return cfg.getDouble(base + "." + key, def); }

    public int integer(String key, int def) { return cfg.getInt(base + "." + key, def); }

    public boolean bool(String key, boolean def) { return cfg.getBoolean(base + "." + key, def); }

    /** A config value in seconds, returned as ticks. */
    public int ticks(String key, double defSeconds) {
        return (int) Math.max(0, Math.round(num(key, defSeconds) * 20.0));
    }

    /** A second particle/sound pair, read from keys starting with the prefix (e.g. "impact-"). */
    public Fx extraFx(String prefix) {
        return extraFx.computeIfAbsent(prefix, p -> Fx.load(plugin, cfg, base, p));
    }
}

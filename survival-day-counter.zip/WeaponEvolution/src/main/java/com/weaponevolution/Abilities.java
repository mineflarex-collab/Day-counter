package com.weaponevolution;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Every ability in the plugin. Spear abilities pierce and thrust; mace abilities smash and shake the ground.
 * All numbers are read from config.yml through {@link AbilitySettings}.
 */
final class Abilities {

    /** Cooldown map key of Thunder Strike (type:id), used by the action-bar countdown. */
    static final String THUNDER_STRIKE_KEY = "spear:thunder-strike";

    private Abilities() {
    }

    static List<Ability> createAll() {
        return List.of(
                // spear
                new PiercingThrust(), new GildedMark(), new FrostSkewer(),
                new InfernalImpale(), new BeastRend(), new ImpalingCharge(), new ThunderStrike(),
                // mace
                new CrushingBlow(), new Concussion(), new ShockwaveSlam(),
                new MagmaQuake(), new TitansWrath(), new BeastRoar());
    }

    private abstract static class Base implements Ability {
        private final WeaponType type;
        private final String id;
        private final String name;
        private final Trigger trigger;
        private final Tier tier;
        private final String description;

        Base(WeaponType type, String id, String name, Trigger trigger, Tier tier, String description) {
            this.type = type;
            this.id = id;
            this.name = name;
            this.trigger = trigger;
            this.tier = tier;
            this.description = description;
        }

        @Override public WeaponType type() { return type; }
        @Override public String id() { return id; }
        @Override public String name() { return name; }
        @Override public Trigger trigger() { return trigger; }
        @Override public Tier defaultTier() { return tier; }
        @Override public String description() { return description; }
    }

    private static Location center(LivingEntity e) {
        return e.getBoundingBox().getCenter().toLocation(e.getWorld());
    }

    // =================================================================== SPEAR

    /** Iron: the thrust passes through the target and hits whoever stands behind it. */
    private static final class PiercingThrust extends Base {
        PiercingThrust() {
            super(WeaponType.SPEAR, "piercing-thrust", "Piercing Thrust", Trigger.ON_HIT, Tier.IRON,
                    "Your thrust passes through the target and hits enemies behind it.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            Player p = c.player();
            LivingEntity victim = c.victim();
            AbilitySettings s = c.s();
            double range = s.num("range", 3.5);
            double width = s.num("width", 1.0);
            double pct = s.num("damage-percent", 60) / 100.0;
            int max = Math.max(1, s.integer("max-targets", 2));

            Vector origin = victim.getBoundingBox().getCenter();
            Vector dir = origin.clone().subtract(p.getEyeLocation().toVector());
            if (dir.lengthSquared() < 1.0E-6) return false;
            dir.normalize();
            World w = victim.getWorld();

            List<LivingEntity> hits = new ArrayList<>();
            for (LivingEntity t : w.getNearbyLivingEntities(origin.toLocation(w), range + 1.0)) {
                if (t == victim || !c.mgr().validTarget(p, t)) continue;
                Vector rel = t.getBoundingBox().getCenter().subtract(origin);
                double along = rel.dot(dir);
                if (along < 0.2 || along > range) continue;
                double off = rel.clone().subtract(dir.clone().multiply(along)).length();
                if (off > width + t.getWidth() / 2.0) continue;
                hits.add(t);
            }
            if (hits.isEmpty()) return false;

            Location vLoc = victim.getLocation();
            hits.sort(Comparator.comparingDouble(t -> t.getLocation().distanceSquared(vLoc)));
            double damage = c.damage() * pct;
            for (int i = 0; i < Math.min(max, hits.size()); i++) {
                c.mgr().damageLater(p, hits.get(i), damage, false);
            }

            for (double d = 0.0; d <= range; d += 0.4) {
                s.fx.point(w, origin.getX() + dir.getX() * d, origin.getY() + dir.getY() * d,
                        origin.getZ() + dir.getZ() * d);
            }
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Gold: marks the target so everyone can see it, and shields the wielder. */
    private static final class GildedMark extends Base {
        GildedMark() {
            super(WeaponType.SPEAR, "gilded-mark", "Gilded Mark", Trigger.ON_HIT, Tier.GOLD,
                    "Marks the target with a golden glow and grants you a brief shield.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            c.victim().addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, s.ticks("glow-seconds", 6), 0));
            c.player().addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION,
                    s.ticks("absorption-seconds", 8), s.integer("absorption-amplifier", 0)));
            s.fx.play(center(c.victim()));
            return true;
        }
    }

    /** Diamond: armor-piercing bonus damage and a freezing chill. */
    private static final class FrostSkewer extends Base {
        FrostSkewer() {
            super(WeaponType.SPEAR, "frost-skewer", "Frost Skewer", Trigger.ON_HIT, Tier.DIAMOND,
                    "Skewers through armor for bonus damage and freezes the target.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            LivingEntity victim = c.victim();
            c.mgr().damageLater(c.player(), victim, s.num("bonus-damage", 3.0), true);
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                    s.ticks("slow-seconds", 3), s.integer("slow-amplifier", 1)));
            if (s.bool("freeze", true)) victim.setFreezeTicks(victim.getMaxFreezeTicks());
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Netherite: sets the target ablaze and drains a little health back. */
    private static final class InfernalImpale extends Base {
        InfernalImpale() {
            super(WeaponType.SPEAR, "infernal-impale", "Infernal Impale", Trigger.ON_HIT, Tier.NETHERITE,
                    "Ignites the target and heals you for part of the damage dealt.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            LivingEntity victim = c.victim();
            victim.setFireTicks(Math.max(victim.getFireTicks(), s.ticks("fire-seconds", 4)));
            double heal = Math.min(s.num("lifesteal-max", 4.0), c.damage() * s.num("lifesteal-percent", 25) / 100.0);
            c.mgr().heal(c.player(), heal);
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Beast: withering wounds that bite through armor. */
    private static final class BeastRend extends Base {
        BeastRend() {
            super(WeaponType.SPEAR, "beast-rend", "Beast Rend", Trigger.ON_HIT, Tier.BEAST,
                    "Rends the target with Wither and extra armor-piercing damage.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            LivingEntity victim = c.victim();
            victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER,
                    s.ticks("wither-seconds", 4), s.integer("wither-amplifier", 1)));
            c.mgr().damageLater(c.player(), victim, c.damage() * s.num("bonus-damage-percent", 20) / 100.0, true);
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Beast ultimate: dash forward and run through everything in the way. */
    private static final class ImpalingCharge extends Base {
        ImpalingCharge() {
            super(WeaponType.SPEAR, "impaling-charge", "Impaling Charge", Trigger.ACTIVE, Tier.BEAST,
                    "Dash forward, impaling every enemy in your path.");
        }

        @Override
        public boolean onActivate(AbilityContext c) {
            final Player p = c.player();
            final AbilitySettings s = c.s();
            final AbilityManager mgr = c.mgr();
            final double speed = s.num("speed", 1.4);
            final int ticks = Math.max(1, s.integer("ticks", 7));
            final double damage = s.num("damage", 8.0);
            final double width = s.num("width", 1.8);
            final int max = Math.max(1, s.integer("max-targets", 6));
            final double knock = s.num("knockback", 0.5);
            final double knockUp = s.num("knockup", 0.4);

            Vector flat = p.getLocation().getDirection().setY(0);
            if (flat.lengthSquared() < 1.0E-4) flat = new Vector(1, 0, 0); // looking straight up or down
            final Vector dash = flat.normalize();
            final Set<UUID> hit = new HashSet<>();

            s.fx.sound(p.getLocation());

            new BukkitRunnable() {
                int tick = 0;

                @Override
                public void run() {
                    if (!p.isOnline() || p.isDead() || tick >= ticks) {
                        cancel();
                        return;
                    }
                    Vector v = dash.clone().multiply(speed);
                    v.setY(tick == 0 ? 0.25 : Math.max(p.getVelocity().getY(), -0.3));
                    p.setVelocity(v);
                    p.setFallDistance(0f);

                    Location here = p.getLocation().add(0, 1, 0);
                    s.fx.particles(here);
                    for (LivingEntity t : p.getWorld().getNearbyLivingEntities(here, width)) {
                        if (hit.size() >= max) break;
                        if (hit.contains(t.getUniqueId()) || !mgr.validTarget(p, t)) continue;
                        hit.add(t.getUniqueId());
                        mgr.damage(p, t, damage, false);
                        mgr.knockbackLater(t, p.getLocation(), knock, knockUp);
                    }
                    tick++;
                }
            }.runTaskTimer(c.plugin(), 0L, 1L);
            return true;
        }
    }

    /**
     * Beast spear only: a hit on an enemy PLAYER calls down lightning at their location.
     * The bolt is strictly visual (strikeLightningEffect): no damage, no fire, no block or mob changes.
     * The cooldown is fixed at exactly 10 seconds and tracked per wielder by the AbilityManager.
     * It only starts when the lightning really fired, so hits on mobs or blocked hits never waste it.
     */
    private static final class ThunderStrike extends Base {
        ThunderStrike() {
            super(WeaponType.SPEAR, "thunder-strike", "Thunder Strike", Trigger.ON_HIT, Tier.BEAST,
                    "Hitting an enemy player calls down a harmless bolt of lightning.");
        }

        @Override public long fixedCooldownMs() { return 10_000L; }

        @Override public Tier fixedMinTier() { return Tier.BEAST; }

        @Override
        public boolean onHit(AbilityContext c) {
            // Beast spear only. Netherite (same item type) must never get lightning.
            if (c.weapon().type() != WeaponType.SPEAR || c.weapon().tier() != Tier.BEAST) return false;
            Player p = c.player();
            if (!(c.victim() instanceof Player target)) return false; // players only, never mobs
            if (!c.mgr().validTarget(p, target) || c.mgr().sameTeam(p, target)) return false;

            Location at = target.getLocation();
            World w = at.getWorld();
            if (w == null) return false;
            w.strikeLightningEffect(at); // visual only: no damage, no fire

            AbilitySettings s = c.s();
            // A crackling column of electric sparks along the bolt, plus a burst and the thunder sound.
            for (double y = 0.0; y <= 4.0; y += 0.5) {
                s.fx.point(w, at.getX(), at.getY() + y, at.getZ());
            }
            s.fx.play(center(target));
            return true;
        }
    }

    // =================================================================== MACE

    /** Iron: a heavy blow that shoves the target back and breaks shields. */
    private static final class CrushingBlow extends Base {
        CrushingBlow() {
            super(WeaponType.MACE, "crushing-blow", "Crushing Blow", Trigger.ON_HIT, Tier.IRON,
                    "Knocks the target back and disables their shield.");
        }

        @Override public boolean worksWhenBlocked() { return true; }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            LivingEntity victim = c.victim();
            if (victim instanceof Player vp && vp.isBlocking()) {
                vp.setCooldown(Material.SHIELD, s.ticks("shield-disable-seconds", 3));
                vp.clearActiveItem();
            }
            c.mgr().knockbackLater(victim, c.player().getLocation(), s.num("knockback", 0.7), s.num("knockup", 0.25));
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Gold: rattles the target's head. */
    private static final class Concussion extends Base {
        Concussion() {
            super(WeaponType.MACE, "concussion", "Concussion", Trigger.ON_HIT, Tier.GOLD,
                    "Rattles the target with Nausea and Slowness.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            LivingEntity victim = c.victim();
            victim.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, s.ticks("nausea-seconds", 5), 0));
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                    s.ticks("slow-seconds", 3), s.integer("slow-amplifier", 0)));
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Diamond: a smash sends a shockwave through everything around the target. */
    private static final class ShockwaveSlam extends Base {
        ShockwaveSlam() {
            super(WeaponType.MACE, "shockwave-slam", "Shockwave Slam", Trigger.ON_SMASH, Tier.DIAMOND,
                    "A smash sends a shockwave that damages and launches nearby enemies.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            double minFall = s.num("min-fall", 2.5);
            if (c.fallDistance() < minFall) return false;

            Player p = c.player();
            double radius = s.num("radius", 4.0);
            double damage = Math.min(s.num("max-damage", 10.0),
                    s.num("damage", 4.0) + s.num("damage-per-block", 0.4) * (c.fallDistance() - minFall));
            double kb = s.num("knockback", 0.9);
            double up = s.num("knockup", 0.5);
            Location origin = c.victim().getLocation();
            LivingEntity victim = c.victim();

            s.fx.sound(origin);
            s.fx.particles(origin);
            c.mgr().ring(origin, radius, s.fx, 8);
            c.mgr().later(() -> {
                for (LivingEntity t : c.mgr().targetsAround(p, origin, radius, victim)) {
                    c.mgr().damage(p, t, damage, false);
                    c.mgr().knockback(t, origin, kb, up);
                }
            });
            return true;
        }
    }

    /** Netherite: the slam splits the ground open and sets the area ablaze. */
    private static final class MagmaQuake extends Base {
        MagmaQuake() {
            super(WeaponType.MACE, "magma-quake", "Magma Quake", Trigger.ON_SMASH, Tier.NETHERITE,
                    "A smash cracks the ground open and ignites everything nearby.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            if (c.fallDistance() < s.num("min-fall", 3.0)) return false;

            Player p = c.player();
            double radius = s.num("radius", 5.5);
            double damage = s.num("damage", 2.0);
            int fire = s.ticks("fire-seconds", 4);
            Location origin = c.victim().getLocation();
            LivingEntity victim = c.victim();

            s.fx.sound(origin);
            s.fx.particles(origin);
            c.mgr().ring(origin, radius, s.fx, 10);
            c.mgr().later(() -> {
                for (LivingEntity t : c.mgr().targetsAround(p, origin, radius, null)) {
                    t.setFireTicks(Math.max(t.getFireTicks(), fire));
                    if (t != victim) c.mgr().damage(p, t, damage, false);
                }
            });
            return true;
        }
    }

    /** Beast: a true skyfall strike. Lightning, Wither and armor-piercing bonus damage. */
    private static final class TitansWrath extends Base {
        TitansWrath() {
            super(WeaponType.MACE, "titans-wrath", "Titan's Wrath", Trigger.ON_SMASH, Tier.BEAST,
                    "A big-drop smash calls down lightning, withers the target and bites through armor.");
        }

        @Override
        public boolean onHit(AbilityContext c) {
            AbilitySettings s = c.s();
            if (c.fallDistance() < s.num("min-fall", 4.0)) return false;

            LivingEntity victim = c.victim();
            if (s.bool("lightning", true)) victim.getWorld().strikeLightningEffect(victim.getLocation());
            victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER,
                    s.ticks("wither-seconds", 4), s.integer("wither-amplifier", 0)));
            c.mgr().damageLater(c.player(), victim, c.damage() * s.num("bonus-damage-percent", 25) / 100.0, true);
            s.fx.play(center(victim));
            return true;
        }
    }

    /** Beast ultimate: a roar that blasts everything around the wielder. */
    private static final class BeastRoar extends Base {
        BeastRoar() {
            super(WeaponType.MACE, "beast-roar", "Beast Roar", Trigger.ACTIVE, Tier.BEAST,
                    "A roaring shockwave damages and hurls back everything around you.");
        }

        @Override
        public boolean onActivate(AbilityContext c) {
            AbilitySettings s = c.s();
            Player p = c.player();
            double radius = s.num("radius", 8.0);
            double damage = s.num("damage", 10.0);
            double kb = s.num("knockback", 1.6);
            double up = s.num("knockup", 0.6);
            Location origin = p.getLocation().clone();
            Fx impact = s.extraFx("impact-");

            s.fx.sound(origin);
            impact.play(origin.clone().add(0, 1, 0));
            c.mgr().ring(origin, radius, s.fx, 10);

            for (LivingEntity t : c.mgr().targetsAround(p, origin, radius, null)) {
                c.mgr().damage(p, t, damage, false);
                c.mgr().knockback(t, origin, kb, up);
                t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                        s.ticks("slow-seconds", 3), s.integer("slow-amplifier", 1)));
            }

            p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH,
                    s.ticks("strength-seconds", 6), s.integer("strength-amplifier", 0)));
            p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION,
                    s.ticks("absorption-seconds", 8), s.integer("absorption-amplifier", 2)));
            p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,
                    s.ticks("resistance-seconds", 5), s.integer("resistance-amplifier", 0)));
            return true;
        }
    }
}

package com.weaponevolution;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Everything an ability needs when it fires.
 *
 * @param victim       the entity that was hit; null for active (key-press) abilities
 * @param damage       final damage of the triggering hit (0 for active abilities)
 * @param smash        true if the hit counted as a mace smash (falling attack)
 * @param fallDistance the wielder's fall distance when the hit landed
 */
public record AbilityContext(WeaponEvolution plugin, AbilityManager mgr, Player player, LivingEntity victim,
                             double damage, boolean smash, double fallDistance, WeaponInfo weapon,
                             AbilitySettings s) {
}

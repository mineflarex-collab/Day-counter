package com.weaponevolution;

/** One custom weapon ability. Numbers, cooldowns, particles and sounds all come from config.yml. */
public interface Ability {

    enum Trigger {
        /** Rolls on every melee hit. */
        ON_HIT("On Hit"),
        /** Rolls only on a mace smash (a falling hit). */
        ON_SMASH("On Smash"),
        /** Cast with Sneak + Swap-Hands (F). */
        ACTIVE("Sneak + F");

        private final String label;

        Trigger(String label) { this.label = label; }

        public String label() { return label; }
    }

    /** Config id, e.g. "piercing-thrust". Lives under abilities.<type>.<id>. */
    String id();

    WeaponType type();

    String name();

    Trigger trigger();

    /** Tier that unlocks this ability unless config.yml overrides min-tier. */
    Tier defaultTier();

    /** Short lore text. Must not contain MiniMessage tags. */
    String description();

    /** Cooldown in ms that config.yml cannot change, or -1 to read it from config.yml. */
    default long fixedCooldownMs() { return -1L; }

    /** Tier that config.yml cannot change (the ability exists at exactly this tier and up), or null. */
    default Tier fixedMinTier() { return null; }

    /** If true the ability still fires when a shield fully absorbed the hit. */
    default boolean worksWhenBlocked() { return false; }

    /** @return true if the ability actually did something (this is what starts the cooldown). */
    default boolean onHit(AbilityContext c) { return false; }

    /** @return true if the ability was cast (this is what starts the cooldown). */
    default boolean onActivate(AbilityContext c) { return false; }
}

package com.weaponevolution;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory view of the SQLite progress tables: each online player's tier for every weapon type, the abilities
 * they have unlocked, plus the global set of retired weapon ids. The database stays the source of truth;
 * evolutions are written to it first and only then applied here.
 */
public final class ProgressManager {

    /** @param weaponId id of the player's current registered weapon; null for Wooden or legacy weapons */
    public record Progress(Tier tier, int kills, String weaponId) {}

    private static final Progress DEFAULT = new Progress(Tier.WOODEN, 0, null);

    private final WeaponEvolution plugin;
    private final DatabaseManager database;
    private final Map<UUID, Map<WeaponType, Progress>> cache = new ConcurrentHashMap<>();
    private final Map<UUID, Map<WeaponType, Set<String>>> unlocked = new ConcurrentHashMap<>();
    private final Set<String> retired = ConcurrentHashMap.newKeySet();

    public ProgressManager(WeaponEvolution plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
    }

    public void loadRetired() throws SQLException {
        retired.addAll(database.loadRetiredIds());
    }

    public boolean isRetired(String weaponId) {
        return weaponId != null && retired.contains(weaponId);
    }

    public void retire(String weaponId) {
        if (weaponId != null) retired.add(weaponId);
    }

    /**
     * Loads a player's saved progress off the main thread, then (back on the main thread, only if the player is
     * still online) makes it available and runs onLoaded. Until it finishes the player cannot evolve weapons.
     */
    public void load(UUID uuid, Runnable onLoaded) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<WeaponType, Progress> loaded;
            Map<WeaponType, Set<String>> abilities;
            try {
                loaded = new ConcurrentHashMap<>(database.loadProgress(uuid));
                abilities = new ConcurrentHashMap<>(database.loadUnlocked(uuid));
            } catch (SQLException e) {
                plugin.getLogger().severe("Could not load weapon progress for " + uuid + ": " + e.getMessage());
                return;
            }
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (plugin.getServer().getPlayer(uuid) == null) return; // left while loading
                cache.put(uuid, loaded);
                Map<WeaponType, Set<String>> sets = new EnumMap<>(WeaponType.class);
                abilities.forEach((type, ids) -> {
                    Set<String> set = ConcurrentHashMap.newKeySet();
                    set.addAll(ids);
                    sets.put(type, set);
                });
                unlocked.put(uuid, new ConcurrentHashMap<>(sets));
                if (onLoaded != null) onLoaded.run();
            });
        });
    }

    public void unload(UUID uuid) {
        cache.remove(uuid);
        unlocked.remove(uuid);
    }

    public boolean isLoaded(UUID uuid) {
        return cache.containsKey(uuid);
    }

    /** @return the player's progress for this weapon (Wooden if none yet), or null if not loaded. */
    public Progress get(UUID uuid, WeaponType type) {
        Map<WeaponType, Progress> map = cache.get(uuid);
        if (map == null) return null;
        return map.getOrDefault(type, DEFAULT);
    }

    public void set(UUID uuid, WeaponType type, Progress progress) {
        Map<WeaponType, Progress> map = cache.get(uuid);
        if (map != null) map.put(type, progress);
    }

    /** Ids of the abilities this player has unlocked for a weapon type (empty if none or not loaded). */
    public Set<String> unlockedIds(UUID uuid, WeaponType type) {
        Map<WeaponType, Set<String>> map = unlocked.get(uuid);
        if (map == null) return Collections.emptySet();
        return map.getOrDefault(type, Collections.emptySet());
    }

    public void clearUnlocked(UUID uuid, WeaponType type) {
        Map<WeaponType, Set<String>> map = unlocked.get(uuid);
        if (map != null) map.remove(type);
    }

    public void addUnlocked(UUID uuid, WeaponType type, Collection<String> ids) {
        Map<WeaponType, Set<String>> map = unlocked.get(uuid);
        if (map == null || ids == null || ids.isEmpty()) return;
        map.computeIfAbsent(type, k -> ConcurrentHashMap.newKeySet()).addAll(ids);
    }
}

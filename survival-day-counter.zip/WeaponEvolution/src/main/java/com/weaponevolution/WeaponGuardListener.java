package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Allay;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

/**
 * Weapons are soulbound: an evolved weapon can only ever live in its owner's own inventory.
 * That closes the usual duplication routes at the source instead of trying to clean up afterwards:
 * <ul>
 *   <li><b>Storage</b> - chests, ender chests, shulkers, barrels, hoppers, droppers, horses, minecarts, bundles,
 *       item frames, armor stands, allays and decorated pots can't receive a weapon.</li>
 *   <li><b>Trading</b> - a weapon can't be dropped, so it can't be handed over; other players, mobs and hoppers
 *       can't pick one up; trade GUIs are inventories and are blocked like any other container.</li>
 *   <li><b>Death</b> - handled by {@link RestoreService} (weapons never drop, they come back on respawn).</li>
 *   <li><b>Dropped anyway</b> (another plugin, a failed save) - the item entity never despawns, can't be burned,
 *       blown up or damaged, and only its owner can pick it up.</li>
 * </ul>
 * Crafting tables, anvils, enchanting tables and grindstones stay usable, because items placed there always
 * return to the player (and the Beast recipe needs the crafting table).
 */
public final class WeaponGuardListener implements Listener {

    /** Inventories a weapon may be placed in: the player's own, or tools whose items always come back. */
    private static final Set<InventoryType> SAFE = EnumSet.of(
            InventoryType.PLAYER, InventoryType.CRAFTING, InventoryType.WORKBENCH, InventoryType.ANVIL,
            InventoryType.ENCHANTING, InventoryType.GRINDSTONE, InventoryType.SMITHING, InventoryType.CREATIVE);

    private final WeaponManager weapons;
    private final ProgressManager progress;

    public WeaponGuardListener(WeaponManager weapons, ProgressManager progress) {
        this.weapons = weapons;
        this.progress = progress;
    }

    private boolean isWeapon(ItemStack item) {
        return weapons.getWeaponId(item) != null;
    }

    private static boolean isBundle(ItemStack item) {
        return item != null && item.getType().name().endsWith("BUNDLE");
    }

    private static void deny(HumanEntity who) {
        if (who instanceof Player p) {
            p.sendActionBar(Component.text("Evolution weapons are soulbound: no dropping, trading or storing.",
                    NamedTextColor.RED));
        }
    }

    // ------------------------------------------------------------------ inventories

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        ItemStack cursor = e.getCursor();
        ItemStack current = e.getCurrentItem();
        ClickType click = e.getClick();
        InventoryAction action = e.getAction();

        // Dropping: Q on a slot, clicking outside the window with the weapon on the cursor, drop actions.
        boolean dropAction = action == InventoryAction.DROP_ALL_CURSOR || action == InventoryAction.DROP_ONE_CURSOR
                || action == InventoryAction.DROP_ALL_SLOT || action == InventoryAction.DROP_ONE_SLOT
                || click == ClickType.DROP || click == ClickType.CONTROL_DROP;
        if (dropAction && (isWeapon(cursor) || isWeapon(current))) {
            e.setCancelled(true);
            deny(e.getWhoClicked());
            return;
        }

        // Bundles can hold items: keep weapons out of them (and bundles from sucking them up).
        if ((isBundle(cursor) && isWeapon(current)) || (isWeapon(cursor) && isBundle(current))) {
            e.setCancelled(true);
            deny(e.getWhoClicked());
            return;
        }

        if (SAFE.contains(top.getType())) return;

        // An outside inventory (chest, ender chest, hopper, villager, horse, trade GUI ...) is open.
        boolean clickedTop = e.getRawSlot() >= 0 && e.getRawSlot() < top.getSize();
        boolean moves = false;
        if (clickedTop) {
            if (isWeapon(cursor)) moves = true; // placing / swapping with the cursor
            if (click == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0
                    && isWeapon(e.getWhoClicked().getInventory().getItem(e.getHotbarButton()))) {
                moves = true; // hotbar key swaps a weapon into the container
            }
            if (click == ClickType.SWAP_OFFHAND && isWeapon(e.getWhoClicked().getInventory().getItemInOffHand())) {
                moves = true;
            }
        } else if (isWeapon(current)
                && (e.isShiftClick() || action == InventoryAction.MOVE_TO_OTHER_INVENTORY)) {
            moves = true; // shift-click from the player's inventory into the container
        }
        if (moves) {
            e.setCancelled(true);
            deny(e.getWhoClicked());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (!isWeapon(e.getOldCursor())) return;
        Inventory top = e.getView().getTopInventory();
        if (SAFE.contains(top.getType())) return;
        for (int raw : e.getRawSlots()) {
            if (raw < top.getSize()) {
                e.setCancelled(true);
                deny(e.getWhoClicked());
                return;
            }
        }
    }

    /** Hoppers, droppers and hopper minecarts never move a weapon (old copies already stored stay put). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(InventoryMoveItemEvent e) {
        if (isWeapon(e.getItem())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSmithing(PrepareSmithingEvent e) {
        // A smithing upgrade would turn the weapon into an unregistered vanilla item.
        if (isWeapon(e.getInventory().getInputEquipment())) e.setResult(null);
    }

    // ------------------------------------------------------------------ dropping and picking up

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (isWeapon(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    /** Creative mode has its own click event (it does not reach onClick): clicking outside drops the cursor item. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCreativeClick(InventoryCreativeEvent e) {
        if (e.getSlotType() == InventoryType.SlotType.OUTSIDE && isWeapon(e.getCursor())) {
            e.setCancelled(true);
            deny(e.getWhoClicked());
        }
    }

    /** A weapon that still ends up as an item entity (other plugins, a failed save) can't be lost to time or damage. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent e) {
        Item item = e.getEntity();
        String id = weapons.getWeaponId(item.getItemStack());
        if (id == null || progress.isRetired(id)) return; // dead copies may despawn like any other item
        item.setUnlimitedLifetime(true);
        item.setInvulnerable(true);
        UUID owner = weapons.getOwner(item.getItemStack());
        if (owner != null) item.setOwner(owner);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemDespawn(ItemDespawnEvent e) {
        String id = weapons.getWeaponId(e.getEntity().getItemStack());
        if (id != null && !progress.isRetired(id)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Item item)) return;
        String id = weapons.getWeaponId(item.getItemStack());
        if (id != null && !progress.isRetired(id)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        ItemStack item = e.getItem().getItemStack();
        String id = weapons.getWeaponId(item);
        if (id == null) return;
        if (!(e.getEntity() instanceof Player p)) {
            e.setCancelled(true); // mobs never take weapons
            return;
        }
        if (progress.isRetired(id)) {
            e.setCancelled(true);
            e.getItem().remove(); // dead copy: delete it
            return;
        }
        UUID owner = weapons.getOwner(item);
        if (owner != null && !owner.equals(p.getUniqueId())) {
            e.setCancelled(true); // only the owner can pick a weapon up
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHopperPickup(InventoryPickupItemEvent e) {
        if (isWeapon(e.getItem().getItemStack())) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ things that can hold an item

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityInteract(PlayerInteractEntityEvent e) {
        guardEntity(e);
    }

    /** Armor stands fire this subclass, which has its own handler list, so it needs its own handler. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityInteractAt(PlayerInteractAtEntityEvent e) {
        guardEntity(e);
    }

    private void guardEntity(PlayerInteractEntityEvent e) {
        Entity target = e.getRightClicked();
        if (!(target instanceof ItemFrame || target instanceof ArmorStand || target instanceof Allay)) return;
        ItemStack inHand = e.getPlayer().getInventory().getItem(e.getHand());
        if (isWeapon(inHand)) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() != Material.DECORATED_POT) return; // the only block that takes any item
        if (isWeapon(e.getItem())) {
            e.setUseInteractedBlock(Event.Result.DENY);
            e.setUseItemInHand(Event.Result.DENY);
            deny(e.getPlayer());
        }
    }
}

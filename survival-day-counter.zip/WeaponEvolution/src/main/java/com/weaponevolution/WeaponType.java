package com.weaponevolution;

import org.bukkit.Material;

import java.util.Locale;
import java.util.function.Function;

/** The weapon families that can evolve. */
public enum WeaponType {

    SPEAR("Spear", tier -> switch (tier) {
        case WOODEN -> Material.WOODEN_SPEAR;
        case COPPER -> Material.COPPER_SPEAR;
        case IRON -> Material.IRON_SPEAR;
        case GOLD -> Material.GOLDEN_SPEAR;
        case DIAMOND -> Material.DIAMOND_SPEAR;
        case NETHERITE, BEAST -> Material.NETHERITE_SPEAR;
    }),

    // Vanilla only has one mace item, so every mace tier is told apart by item data.
    MACE("Mace", tier -> Material.MACE);

    private final String displayName;
    private final Function<Tier, Material> materials;

    WeaponType(String displayName, Function<Tier, Material> materials) {
        this.displayName = displayName;
        this.materials = materials;
    }

    public String displayName() { return displayName; }
    public Material material(Tier tier) { return materials.apply(tier); }
    public String configKey() { return name().toLowerCase(Locale.ROOT); }

    /** @return the weapon type that uses this material, or null. */
    public static WeaponType of(Material material) {
        for (WeaponType type : values()) {
            for (Tier tier : Tier.values()) {
                if (type.material(tier) == material) return type;
            }
        }
        return null;
    }

    public static WeaponType parse(String s) {
        if (s == null) return null;
        try {
            return valueOf(s.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}

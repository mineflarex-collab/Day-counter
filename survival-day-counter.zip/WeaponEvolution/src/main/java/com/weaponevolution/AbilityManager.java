package com.weaponevolution;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Owns ability settings, cooldowns, passive effects and the shared damage/target helpers. */
public final class AbilityManager {

    /** Passive effects are short and refreshed constantly so they vanish when the weapon is put away. */
    private static final int PASSIVE_TICKS = 30;

    private final WeaponEvolution plugin;
    private final List<Ability> abilities = Abilities.createAll();
    private final Map<String, AbilitySettings> settings = new HashMap<>();
    private final Map<WeaponType, Map<Tier, List<PotionEffect>>> passives = new EnumMap<>(WeaponType.class);
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    /** Players whose ability damage is being dealt right now (stops abilities triggering themselves). */
    private final Set<UUID> guard = new HashSet<>();

    public AbilityManager(WeaponEvolution plugin) {
        this.plugin = plugin;
        reload();
    }

    // ------------------------------------------------------------------ config

    public void reload() {
        settings.clear();
        for (Ability a : abilities) {
            settings.put(key(a), new AbilitySettings(plugin, a));
        }
        loadPassives();
    }

    public String key(Ability a) {
        return a.type().configKey() + ":" + a.id();
    }

    public AbilitySettings settings(Ability a) {
        return settings.get(key(a));
    }

    public List<Ability> all() {
        return abilities;
    }

    /** Enabled abilities this weapon has unlocked (tier is cumulative: higher tiers keep earlier abilities). */
    public List<Ability> unlocked(WeaponInfo w) {
        List<Ability> out = new ArrayList<>();
        if (w.tier() == Tier.WOODEN) return out; // wooden weapons have no abilities
        for (Ability a : abilities) {
            if (a.type() != w.type()) continue;
            AbilitySettings s = settings(a);
            if (s != null && s.enabled && w.tier().atLeast(s.minTier)) out.add(a);
        }
        return out;
    }

    private ProgressManager progress;

    public void setProgress(ProgressManager progress) {
        this.progress = progress;
    }

    /**
     * Abilities this player's weapon can use: everything the tier unlocks right now, plus every ability the
     * player has ever unlocked (saved in the database), so a config change can't take an unlocked ability away.
     */
    public List<Ability> unlockedFor(UUID player, WeaponInfo w) {
        List<Ability> out = unlocked(w);
        if (progress == null || w.tier() == Tier.WOODEN) return out;
        Set<String> saved = progress.unlockedIds(player, w.type());
        if (saved.isEmpty()) return out;
        for (Ability a : abilities) {
            if (a.type() != w.type() || out.contains(a) || !saved.contains(a.id())) continue;
            AbilitySettings s = settings(a);
            if (s != null && s.enabled) out.add(a);
        }
        return out;
    }

    private void loadPassives() {
        passives.clear();
        for (WeaponType type : WeaponType.values()) {
            Map<Tier, List<PotionEffect>> perTier = new EnumMap<>(Tier.class);
            Map<PotionEffectType, Integer> running = new LinkedHashMap<>();
            for (Tier tier : Tier.values()) {
                if (tier != Tier.WOODEN) { // wooden never gets passives
                    List<String> raw = plugin.getConfig()
                            .getStringList("passives." + type.configKey() + "." + tier.configKey());
                    for (String entry : raw) {
                        parsePassive(entry, running);
                    }
                }
                List<PotionEffect> effects = new ArrayList<>();
                if (tier != Tier.WOODEN) {
                    running.forEach((t, amp) -> effects.add(new PotionEffect(t, PASSIVE_TICKS, amp, true, false, true)));
                }
                perTier.put(tier, effects);
            }
            passives.put(type, perTier);
        }
    }

    /** Entry format: "speed:0" (effect id, then amplifier where 0 = level I). */
    private void parsePassive(String entry, Map<PotionEffectType, Integer> running) {
        String id = entry.trim();
        int amp = 0;
        int colon = id.lastIndexOf(':');
        if (colon > 0) {
            try {
                amp = Math.max(0, Integer.parseInt(id.substring(colon + 1).trim()));
                id = id.substring(0, colon);
            } catch (NumberFormatException ignored) {
                // no amplifier given: the colon belongs to a namespace like "minecraft:speed"
            }
        }
        NamespacedKey nk = NamespacedKey.fromString(id.trim().toLowerCase(Locale.ROOT));
        PotionEffectType type = nk == null ? null : Registry.EFFECT.get(nk);
        if (type == null) {
            plugin.getLogger().warning("Unknown passive effect '" + entry + "' in config.yml - ignoring.");
            return;
        }
        running.merge(type, amp, Math::max);
    }

    public List<PotionEffect> passiveEffects(WeaponType type, Tier tier) {
        Map<Tier, List<PotionEffect>> perTier = passives.get(type);
        return perTier == null ? List.of() : perTier.getOrDefault(tier, List.of());
    }

    /** Applies passive effects without downgrading a stronger effect the player already has. */
    public void applyPassives(Player p, WeaponInfo w) {
        for (PotionEffect effect : passiveEffects(w.type(), w.tier())) {
            PotionEffect current = p.getPotionEffect(effect.getType());
            if (current != null && (current.getAmplifier() > effect.getAmplifier()
                    || (current.getAmplifier() == effect.getAmplifier() && current.getDuration() > PASSIVE_TICKS))) {
                continue;
            }
            p.addPotionEffect(effect);
        }
    }

    /** Human readable passive list for lore, e.g. "Speed I". Empty if none. */
    public String passiveSummary(WeaponType type, Tier tier) {
        List<String> names = new ArrayList<>();
        for (PotionEffect e : passiveEffects(type, tier)) {
            String[] words = e.getType().getKey().getKey().split("_");
            StringBuilder sb = new StringBuilder();
            for (String word : words) {
                if (word.isEmpty()) continue;
                if (sb.length() > 0) sb.append(' ');
                sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
            }
            names.add(sb + " " + roman(e.getAmplifier() + 1));
        }
        return String.join(", ", names);
    }

    private static String roman(int n) {
        String[] r = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 1 && n <= r.length ? r[n - 1] : String.valueOf(n);
    }

    // ------------------------------------------------------------------ cooldowns

    public long remaining(UUID id, String key) {
        Map<String, Long> map = cooldowns.get(id);
        if (map == null) return 0L;
        Long readyAt = map.get(key);
        return readyAt == null ? 0L : Math.max(0L, readyAt - System.currentTimeMillis());
    }

    public void startCooldown(UUID id, String key, long ms) {
        if (ms <= 0) return;
        cooldowns.computeIfAbsent(id, k -> new HashMap<>()).put(key, System.currentTimeMillis() + ms);
    }

    /** Drops expired entries; cooldowns still running survive a relog so they can't be reset by quitting. */
    public void cleanup(UUID id) {
        Map<String, Long> map = cooldowns.get(id);
        if (map == null) return;
        long now = System.currentTimeMillis();
        map.values().removeIf(readyAt -> readyAt <= now);
        if (map.isEmpty()) cooldowns.remove(id);
    }

    // ------------------------------------------------------------------ targets & damage

    public boolean validTarget(Player attacker, Entity e) {
        if (!(e instanceof LivingEntity le) || e instanceof ArmorStand || e == attacker) return false;
        if (!le.isValid() || le.isDead()) return false;
        if (e.hasMetadata("NPC")) return false;
        if (e instanceof Player tp) {
            if (tp.getGameMode() == GameMode.CREATIVE || tp.getGameMode() == GameMode.SPECTATOR) return false;
        } else if (!plugin.getConfig().getBoolean("settings.affect-mobs", true)) {
            return false;
        }
        return true;
    }

    /** True if both players are on the same scoreboard team (they are not enemies). */
    public boolean sameTeam(Player a, Player b) {
        org.bukkit.scoreboard.Team ta = a.getScoreboard().getEntryTeam(a.getName());
        org.bukkit.scoreboard.Team tb = b.getScoreboard().getEntryTeam(b.getName());
        return ta != null && tb != null && ta.getName().equals(tb.getName());
    }

    public List<LivingEntity> targetsAround(Player attacker, Location center, double radius, LivingEntity exclude) {
        List<LivingEntity> out = new ArrayList<>();
        double r2 = radius * radius;
        for (LivingEntity t : center.getWorld().getNearbyLivingEntities(center, radius)) {
            if (t == exclude || !validTarget(attacker, t)) continue;
            if (t.getLocation().distanceSquared(center) > r2) continue;
            out.add(t);
        }
        return out;
    }

    public boolean isAbilityDamage(Player attacker) {
        return guard.contains(attacker.getUniqueId());
    }

    /**
     * Deals ability damage through a normal damage event (so protection plugins can cancel it).
     * Abilities never trigger from their own damage. Armor-piercing damage ignores armor.
     */
    public void damage(Player attacker, LivingEntity target, double amount, boolean armorPiercing) {
        if (amount <= 0 || !target.isValid() || target.isDead()) return;
        amount *= plugin.getConfig().getDouble("settings.damage-multiplier", 1.0);
        if (amount <= 0) return;

        boolean added = guard.add(attacker.getUniqueId());
        try {
            target.setNoDamageTicks(0); // otherwise damage right after a hit is swallowed by i-frames
            if (armorPiercing) {
                DamageSource source = DamageSource.builder(DamageType.MAGIC)
                        .withCausingEntity(attacker)
                        .withDirectEntity(attacker)
                        .build();
                target.damage(amount, source);
            } else {
                target.damage(amount, attacker);
            }
        } finally {
            if (added) guard.remove(attacker.getUniqueId());
        }
    }

    /** Runs next tick. Hit abilities use this so they never change health or velocity inside the damage event. */
    public void later(Runnable r) {
        plugin.getServer().getScheduler().runTask(plugin, r);
    }

    public void damageLater(Player attacker, LivingEntity target, double amount, boolean armorPiercing) {
        later(() -> damage(attacker, target, amount, armorPiercing));
    }

    /** Pushes the target away from a point. */
    public void knockback(LivingEntity target, Location from, double horizontal, double vertical) {
        Vector push = target.getLocation().toVector().subtract(from.toVector());
        push.setY(0);
        if (push.lengthSquared() < 1.0E-4) push = new Vector(1, 0, 0);
        push.normalize().multiply(horizontal).setY(vertical);
        target.setVelocity(push);
    }

    public void knockbackLater(LivingEntity target, Location from, double horizontal, double vertical) {
        Location origin = from.clone();
        later(() -> {
            if (target.isValid() && !target.isDead()) knockback(target, origin, horizontal, vertical);
        });
    }

    public void heal(Player p, double amount) {
        if (amount <= 0 || p.isDead()) return;
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        double cap = max != null ? max.getValue() : 20.0;
        p.setHealth(Math.min(cap, p.getHealth() + amount));
        if (plugin.getConfig().getBoolean("settings.particles", true)) {
            p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 4, 0.3, 0.3, 0.3, 0);
        }
    }

    /** An expanding flat ring of the fx particle. */
    public void ring(Location center, double radius, Fx fx, int ticks) {
        if (!fx.hasParticle() || ticks <= 0) return;
        final World w = center.getWorld();
        final Location c = center.clone();
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                double r = radius * t / ticks;
                int points = (int) Math.max(16, r * 8);
                for (int i = 0; i < points; i++) {
                    double a = 2 * Math.PI * i / points;
                    fx.point(w, c.getX() + Math.cos(a) * r, c.getY() + 0.2, c.getZ() + Math.sin(a) * r);
                }
                if (t >= ticks) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}

package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;

import java.sql.SQLException;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Netherite -> Beast is crafted, not earned by a kill: 8 hearts around a Netherite spear (or mace) in a
 * crafting table. The center weapon must be the player's own, registered Netherite weapon. The upgrade is saved
 * to SQLite (compare-and-set) before the Beast weapon is handed over.
 */
public final class BeastCraftListener implements Listener {

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;
    private final ProgressManager progress;
    private final DatabaseManager database;
    private final EvolutionListener evolution;
    private final Map<WeaponType, NamespacedKey> keys = new EnumMap<>(WeaponType.class);

    public BeastCraftListener(WeaponEvolution plugin, WeaponManager weapons, ProgressManager progress,
                              DatabaseManager database, EvolutionListener evolution) {
        this.plugin = plugin;
        this.weapons = weapons;
        this.progress = progress;
        this.database = database;
        this.evolution = evolution;
        for (WeaponType type : WeaponType.values()) {
            keys.put(type, new NamespacedKey(plugin, "beast_" + type.configKey()));
        }
    }

    // ------------------------------------------------------------------ recipes

    /** The heart item from config (default Heart of the Sea). */
    public static Material heartMaterial(WeaponEvolution plugin) {
        String name = plugin.getConfig().getString("evolution.beast-heart-item", "HEART_OF_THE_SEA");
        Material m = Material.matchMaterial(name == null ? "" : name);
        if (m == null || !m.isItem() || m.isAir()) {
            plugin.getLogger().warning("Invalid evolution.beast-heart-item '" + name + "' - using HEART_OF_THE_SEA.");
            return Material.HEART_OF_THE_SEA;
        }
        return m;
    }

    public static String prettyName(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String word : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }

    /** (Re)registers the two shaped recipes: HHH / HXH / HHH with H = heart, X = Netherite spear or mace. */
    public void registerRecipes() {
        unregisterRecipes();
        if (!plugin.getConfig().getBoolean("evolution.beast-requires-crafting", true)) return;
        Material heart = heartMaterial(plugin);
        for (WeaponType type : WeaponType.values()) {
            ShapedRecipe recipe = new ShapedRecipe(keys.get(type), new ItemStack(type.material(Tier.BEAST)));
            recipe.shape("HHH", "HXH", "HHH");
            recipe.setIngredient('H', new RecipeChoice.MaterialChoice(heart));
            recipe.setIngredient('X', new RecipeChoice.MaterialChoice(type.material(Tier.NETHERITE)));
            plugin.getServer().addRecipe(recipe);
        }
    }

    public void unregisterRecipes() {
        for (NamespacedKey key : keys.values()) {
            plugin.getServer().removeRecipe(key);
        }
    }

    private WeaponType typeOf(Recipe recipe) {
        if (!(recipe instanceof Keyed keyed)) return null;
        for (Map.Entry<WeaponType, NamespacedKey> entry : keys.entrySet()) {
            if (entry.getValue().equals(keyed.getKey())) return entry.getKey();
        }
        return null;
    }

    // ------------------------------------------------------------------ validation

    /** @return the player's progress if the center item is their own valid Netherite weapon, else null. */
    private ProgressManager.Progress validate(Player p, WeaponType type, ItemStack center) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return null;
        if (!progress.isLoaded(p.getUniqueId())) return null;
        WeaponInfo w = weapons.getInfo(center);
        if (w == null || w.type() != type || w.tier() != Tier.NETHERITE) return null;
        ProgressManager.Progress prog = progress.get(p.getUniqueId(), type);
        if (prog == null || !weapons.canEvolve(p, center, w, prog)) return null;
        return prog;
    }

    private static ItemStack centerOf(ItemStack[] matrix) {
        return matrix.length >= 9 ? matrix[4] : null; // only the 3x3 crafting table has a center
    }

    // ------------------------------------------------------------------ crafting

    @EventHandler
    public void onPrepare(PrepareItemCraftEvent e) {
        WeaponType type = typeOf(e.getRecipe());
        if (type == null) return;
        if (!(e.getView().getPlayer() instanceof Player p)) {
            e.getInventory().setResult(null);
            return;
        }
        ItemStack center = centerOf(e.getInventory().getMatrix());
        if (validate(p, type, center) == null) {
            e.getInventory().setResult(null); // not your Netherite weapon: nothing to craft
            return;
        }
        // Preview only. The real id is created and saved when the craft is taken.
        e.getInventory().setResult(weapons.createItem(type, Tier.BEAST, center, p.getUniqueId(),
                UUID.randomUUID().toString()));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        WeaponType type = typeOf(e.getRecipe());
        if (type == null) return;
        if (!(e.getWhoClicked() instanceof Player p)) {
            e.setCancelled(true);
            return;
        }
        if (e.isShiftClick()) { // shift-click would craft in bulk
            e.setCancelled(true);
            p.sendActionBar(Component.text("Pick the Beast weapon up normally (no shift-click).", NamedTextColor.GRAY));
            return;
        }

        ItemStack center = centerOf(e.getInventory().getMatrix());
        ProgressManager.Progress prog = validate(p, type, center);
        if (prog == null) {
            e.setCancelled(true);
            return;
        }

        UUID id = p.getUniqueId();
        String oldId = weapons.getWeaponId(center); // null for legacy weapons
        String newId = UUID.randomUUID().toString();
        FileConfiguration cfg = plugin.getConfig();
        try {
            boolean saved = database.recordUpgrade(id, type, prog.tier(), Tier.NETHERITE, Tier.BEAST,
                    oldId, newId, null, "CRAFT", false, weapons.abilityIds(type, Tier.BEAST));
            if (!saved) {
                e.setCancelled(true);
                return;
            }
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not save Beast craft for " + p.getName() + ": " + ex.getMessage());
            e.setCancelled(true); // nothing saved, nothing consumed
            return;
        }

        progress.retire(oldId);
        progress.retire(prog.weaponId());
        progress.addUnlocked(id, type, weapons.abilityIds(type, Tier.BEAST));
        progress.set(id, type, new ProgressManager.Progress(Tier.BEAST, prog.kills(), newId));
        e.setCurrentItem(weapons.createItem(type, Tier.BEAST, center, id, newId));

        plugin.getServer().getScheduler().runTask(plugin, () -> evolution.playEvolution(p, type, Tier.NETHERITE, Tier.BEAST));
        plugin.getLogger().info(p.getName() + " crafted a Beast " + type.displayName() + ".");
    }
}

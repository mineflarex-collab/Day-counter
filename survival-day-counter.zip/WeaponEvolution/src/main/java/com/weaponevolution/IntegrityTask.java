package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Safety net that runs every few seconds over online players' inventories and ender chests.
 * <ul>
 *   <li>Retired weapons (replaced by an evolution or a restore) are deleted.</li>
 *   <li>If the same weapon id exists more than once, only one copy survives (the owner's copy wins).</li>
 *   <li>A weapon found in someone else's inventory (for example from before weapons were soulbound) is taken
 *       back and returned to its owner.</li>
 *   <li>Weapons waiting for room in a full inventory are handed over as soon as there is space.</li>
 * </ul>
 * The soulbound rules stop these situations from arising; this scan cleans up whatever older versions or
 * other plugins left behind.
 */
public final class IntegrityTask extends BukkitRunnable {

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;
    private final ProgressManager progress;
    private final RestoreService restore;

    public IntegrityTask(WeaponEvolution plugin, WeaponManager weapons, ProgressManager progress,
                         RestoreService restore) {
        this.plugin = plugin;
        this.weapons = weapons;
        this.progress = progress;
        this.restore = restore;
    }

    @Override
    public void run() {
        List<Player> players = new ArrayList<>(plugin.getServer().getOnlinePlayers());
        for (Player p : players) restore.tick(p);

        if (!plugin.getConfig().getBoolean("evolution.remove-duplicates", true)) return;

        Set<String> seen = new HashSet<>();
        // Pass 1: copies inside their owner's own inventory claim the id first (and dead copies go everywhere).
        for (Player p : players) {
            scan(p, p.getInventory(), true, seen);
            scan(p, p.getEnderChest(), true, seen);
        }
        // Pass 2: everything else. An id that is already claimed is a duplicate; an unclaimed one that sits in
        // a stranger's inventory goes back to its owner.
        for (Player p : players) {
            scan(p, p.getInventory(), false, seen);
            scan(p, p.getEnderChest(), false, seen);
        }
    }

    private void scan(Player p, Inventory inv, boolean ownerPass, Set<String> seen) {
        ItemStack[] items = inv.getContents();
        for (int i = 0; i < items.length; i++) {
            ItemStack item = items[i];
            String id = weapons.getWeaponId(item);
            if (id == null) continue;

            if (progress.isRetired(id)) {
                if (ownerPass) remove(p, inv, i, "a replaced (retired) weapon");
                continue;
            }
            UUID owner = weapons.getOwner(item);
            boolean mine = p.getUniqueId().equals(owner);
            if (ownerPass) {
                if (mine && !seen.add(id)) remove(p, inv, i, "a duplicated weapon");
                continue;
            }
            if (mine) continue; // handled in pass 1
            if (!seen.add(id)) {
                remove(p, inv, i, "a duplicated weapon");
            } else if (owner != null && restore.returnToOwner(owner, item)) {
                inv.setItem(i, null);
                p.sendMessage(Component.text("A weapon that belongs to another player was returned to them.",
                        NamedTextColor.RED));
                plugin.getLogger().warning("Returned a weapon owned by " + owner + " from " + p.getName()
                        + " (slot " + i + ").");
            }
        }
    }

    private void remove(Player p, Inventory inv, int slot, String what) {
        inv.setItem(slot, null);
        p.sendMessage(Component.text("A duplicated or outdated weapon was removed from your inventory.",
                NamedTextColor.RED));
        plugin.getLogger().warning("Removed " + what + " from " + p.getName() + " (slot " + slot + ").");
    }
}

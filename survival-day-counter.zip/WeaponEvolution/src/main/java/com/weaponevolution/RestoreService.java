package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Keeps every player's weapons in step with the database, with no admin involved.
 *
 * <ul>
 *   <li><b>Join / restart:</b> loads progress, records unlocked abilities, hands back weapons that were waiting
 *       for the player, and re-issues a weapon that is missing (for example after a crash that lost the item
 *       but not the database write).</li>
 *   <li><b>Death:</b> weapons never drop. The exact item is saved in the database and returned on respawn, so
 *       nobody can loot or duplicate it.</li>
 *   <li><b>Break:</b> a weapon that breaks is re-issued at its tier.</li>
 * </ul>
 *
 * Re-issuing is dupe-safe by construction: it retires the old weapon id in the same transaction that creates
 * the new one, so any old copy anywhere in the world is dead the moment the new weapon exists.
 */
public final class RestoreService implements Listener {

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;
    private final ProgressManager progress;
    private final DatabaseManager database;
    /** Online players that have weapons waiting for room in their inventory. */
    private final Set<UUID> pendingOwners = ConcurrentHashMap.newKeySet();

    public RestoreService(WeaponEvolution plugin, WeaponManager weapons, ProgressManager progress,
                          DatabaseManager database) {
        this.plugin = plugin;
        this.weapons = weapons;
        this.progress = progress;
        this.database = database;
    }

    // ------------------------------------------------------------------ session

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        load(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        pendingOwners.remove(e.getPlayer().getUniqueId());
    }

    /** Loads the player's saved progress, then brings their weapons in line with it. */
    public void load(Player player) {
        UUID uuid = player.getUniqueId();
        progress.load(uuid, () -> {
            Player p = plugin.getServer().getPlayer(uuid);
            if (p != null) sync(p);
        });
    }

    private void sync(Player p) {
        recordUnlocked(p);
        Set<String> waiting = deliverPending(p);
        ensureWeapons(p, waiting);
        refreshLore(p);
    }

    /** Brings the lore of the player's weapons up to date (older items learn about newer abilities). */
    private void refreshLore(Player p) {
        org.bukkit.inventory.PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item != null && weapons.getWeaponId(item) != null && weapons.refreshLore(item)) {
                inv.setItem(i, item);
            }
        }
    }

    /** Called every few seconds for every online player: hands over weapons that were waiting for room. */
    public void tick(Player p) {
        if (pendingOwners.contains(p.getUniqueId()) && progress.isLoaded(p.getUniqueId())) {
            deliverPending(p);
        }
    }

    // ------------------------------------------------------------------ unlocked abilities

    /** Makes sure every ability the player's current tiers unlock is saved (covers players from older versions). */
    private void recordUnlocked(Player p) {
        UUID uuid = p.getUniqueId();
        for (WeaponType type : WeaponType.values()) {
            ProgressManager.Progress prog = progress.get(uuid, type);
            if (prog == null || prog.tier() == Tier.WOODEN) continue;
            Set<String> have = progress.unlockedIds(uuid, type);
            List<String> missing = weapons.abilityIds(type, prog.tier()).stream()
                    .filter(id -> !have.contains(id)).toList();
            if (missing.isEmpty()) continue;
            try {
                database.addUnlocked(uuid, type, missing);
                progress.addUnlocked(uuid, type, missing);
            } catch (SQLException ex) {
                plugin.getLogger().severe("Could not save unlocked abilities for " + p.getName() + ": " + ex.getMessage());
            }
        }
    }

    // ------------------------------------------------------------------ waiting weapons

    /**
     * Gives the player the weapons saved for them (after a death, a full inventory, or because they were taken
     * from someone else's inventory).
     *
     * @return ids that are still waiting because the inventory had no room
     */
    private Set<String> deliverPending(Player p) {
        UUID uuid = p.getUniqueId();
        Set<String> stillWaiting = new HashSet<>();
        List<DatabaseManager.Pending> list;
        try {
            list = database.loadPending(uuid);
        } catch (SQLException e) {
            plugin.getLogger().severe("Could not read waiting weapons for " + p.getName() + ": " + e.getMessage());
            return stillWaiting;
        }
        for (DatabaseManager.Pending pending : list) {
            try {
                ItemStack item = ItemStack.deserializeBytes(pending.item());
                WeaponInfo info = weapons.getInfo(item);
                String id = weapons.getWeaponId(item);
                if (info == null || id == null || !id.equals(pending.weaponId())) {
                    database.deletePending(pending.weaponId()); // dead or unreadable copy
                    continue;
                }
                ProgressManager.Progress prog = progress.get(uuid, info.type());
                if (prog == null) { // progress not loaded: try again later
                    stillWaiting.add(id);
                    continue;
                }
                if (!id.equals(prog.weaponId()) || progress.isRetired(id) || holds(p, id)) {
                    database.deletePending(id); // replaced since, or the player already has it
                    continue;
                }
                if (p.getInventory().firstEmpty() < 0) {
                    stillWaiting.add(id);
                    continue;
                }
                p.getInventory().addItem(item);
                database.deletePending(id); // item first, then delete: a crash in between can never lose it
            } catch (Exception ex) {
                plugin.getLogger().severe("Could not return a saved weapon to " + p.getName() + ": " + ex.getMessage());
                stillWaiting.add(pending.weaponId());
            }
        }
        if (stillWaiting.isEmpty()) pendingOwners.remove(uuid);
        else {
            pendingOwners.add(uuid);
            p.sendActionBar(Component.text("Your weapon is waiting - free an inventory slot.", NamedTextColor.GOLD));
        }
        return stillWaiting;
    }

    /**
     * Moves someone else's weapon back to its real owner (online: delivered as soon as there is room;
     * offline: delivered at their next join).
     *
     * @return true if the copy was saved for the owner and the caller should remove it from the holder
     */
    public boolean returnToOwner(UUID owner, ItemStack item) {
        String id = weapons.getWeaponId(item);
        if (id == null) return false;
        try {
            DatabaseManager.WeaponRecord rec = database.findWeapon(id);
            if (rec == null || !"ACTIVE".equals(rec.state()) || !owner.equals(rec.owner())) return false;
            database.savePending(owner, id, item.serializeAsBytes());
            pendingOwners.add(owner);
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Could not return a weapon to its owner: " + e.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------------ missing weapons

    /** Re-issues any evolved weapon the player no longer has. */
    private void ensureWeapons(Player p, Set<String> waiting) {
        UUID uuid = p.getUniqueId();
        for (WeaponType type : WeaponType.values()) {
            ProgressManager.Progress prog = progress.get(uuid, type);
            if (prog == null || prog.tier() == Tier.WOODEN || prog.weaponId() == null) continue;
            if (waiting.contains(prog.weaponId()) || holds(p, prog.weaponId())) continue;

            String newId = UUID.randomUUID().toString();
            try {
                if (!database.reissue(uuid, type, prog.tier(), prog.weaponId(), newId)) continue;
            } catch (SQLException e) {
                plugin.getLogger().severe("Could not restore " + type.displayName() + " for " + p.getName()
                        + ": " + e.getMessage());
                continue;
            }
            progress.retire(prog.weaponId());
            progress.set(uuid, type, new ProgressManager.Progress(prog.tier(), prog.kills(), newId));
            ItemStack item = weapons.createItem(type, prog.tier(), null, uuid, newId);
            if (p.getInventory().firstEmpty() >= 0) {
                p.getInventory().addItem(item);
            } else {
                try {
                    database.savePending(uuid, newId, item.serializeAsBytes());
                    pendingOwners.add(uuid);
                } catch (SQLException e) {
                    plugin.getLogger().severe("Could not save a restored weapon for " + p.getName() + ": " + e.getMessage());
                }
            }
            p.sendMessage(Component.text("Your " + prog.tier().displayName() + " " + type.displayName()
                    + " was restored.", NamedTextColor.GREEN));
            plugin.getLogger().info("Restored " + p.getName() + "'s " + prog.tier().displayName() + " "
                    + type.displayName() + " (it was missing).");
        }
    }

    /** Whether the player carries (inventory or ender chest) a valid copy of this weapon id. */
    private boolean holds(Player p, String id) {
        return contains(p.getInventory().getContents(), id) || contains(p.getEnderChest().getContents(), id);
    }

    private boolean contains(ItemStack[] items, String id) {
        for (ItemStack item : items) {
            if (item == null || !id.equals(weapons.getWeaponId(item))) continue;
            if (weapons.getInfo(item) != null) return true; // null = retired or tier/material mismatch
        }
        return false;
    }

    // ------------------------------------------------------------------ death, respawn, break

    /**
     * Weapons never drop. The victim's active weapon is saved to the database (exact item) BEFORE it is taken
     * out of the drops, so a crash cannot lose it; if the save fails the item simply drops as usual and only
     * its owner can pick it up. Dead copies are deleted.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        resetSpearOnPvpDeath(e);
        if (e.getKeepInventory()) return; // items stay with the player: nothing drops, nothing to return
        Player p = e.getEntity();
        UUID uuid = p.getUniqueId();
        Set<String> saved = new HashSet<>();
        Iterator<ItemStack> it = e.getDrops().iterator();
        while (it.hasNext()) {
            ItemStack item = it.next();
            String id = weapons.getWeaponId(item);
            if (id == null) continue;
            if (progress.isRetired(id)) {
                it.remove(); // dead copy
                continue;
            }
            UUID owner = weapons.getOwner(item);
            WeaponType type = WeaponType.of(item.getType());
            if (type == null || (owner != null && !owner.equals(uuid))) continue; // someone else's: stays a drop
            ProgressManager.Progress prog = progress.get(uuid, type);
            if (prog == null || !id.equals(prog.weaponId())) continue;
            if (saved.contains(id)) {
                it.remove(); // a second copy of the same id can never survive
                continue;
            }
            try {
                database.savePending(uuid, id, item.serializeAsBytes());
            } catch (SQLException ex) {
                plugin.getLogger().severe("Could not save " + p.getName() + "'s weapon on death: " + ex.getMessage());
                // Not saved: keep the exact item with the player through death instead of dropping it.
                e.getItemsToKeep().add(item);
                it.remove();
                continue;
            }
            saved.add(id);
            it.remove();
        }
        if (!saved.isEmpty()) pendingOwners.add(uuid);
    }

    /**
     * Killed by another player: the victim's spear goes back to Wooden (death-reset.spear-on-pvp-death).
     * The reset is saved to SQLite first; then the evolved spear is taken out of the drops (or the inventory
     * with keepInventory) and a plain Wooden Spear is kept for the respawn. The mace is not touched.
     */
    private void resetSpearOnPvpDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Player killer = p.getKiller();
        if (killer == null || killer.equals(p)) return;
        if (!plugin.getConfig().getBoolean("death-reset.spear-on-pvp-death", true)) return;
        UUID uuid = p.getUniqueId();
        ProgressManager.Progress prog = progress.get(uuid, WeaponType.SPEAR);
        if (prog == null || prog.tier() == Tier.WOODEN) return;

        try {
            if (!database.resetToWooden(uuid, WeaponType.SPEAR, prog.tier())) return;
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not reset " + p.getName() + "'s spear on death: " + ex.getMessage());
            return; // nothing saved, nothing changes
        }
        progress.retire(prog.weaponId());
        progress.set(uuid, WeaponType.SPEAR, new ProgressManager.Progress(Tier.WOODEN, prog.kills(), null));
        progress.clearUnlocked(uuid, WeaponType.SPEAR);

        ItemStack wooden = new ItemStack(org.bukkit.Material.WOODEN_SPEAR);
        if (e.getKeepInventory()) {
            org.bukkit.inventory.PlayerInventory inv = p.getInventory();
            boolean given = false;
            for (int i = 0; i < inv.getSize(); i++) {
                if (!isEvolvedSpear(inv.getItem(i))) continue;
                inv.setItem(i, given ? null : wooden);
                given = true;
            }
            if (!given) inv.addItem(wooden);
        } else {
            e.getDrops().removeIf(this::isEvolvedSpear);
            e.getItemsToKeep().add(wooden);
        }
        p.sendMessage(Component.text("You were killed - your spear went back to Wooden.", NamedTextColor.RED));
        plugin.getLogger().info(p.getName() + "'s " + prog.tier().displayName() + " Spear was reset to Wooden (killed by "
                + killer.getName() + ").");
    }

    private boolean isEvolvedSpear(ItemStack item) {
        if (item == null || WeaponType.of(item.getType()) != WeaponType.SPEAR) return false;
        String id = weapons.getWeaponId(item);
        if (id != null) return true; // registered (now retired) spear
        WeaponInfo info = weapons.getInfo(item);
        return info != null && info.tier() != Tier.WOODEN; // legacy spear without an id
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Player p = plugin.getServer().getPlayer(uuid);
            if (p != null && p.isOnline() && progress.isLoaded(uuid)) sync(p);
        }, 2L);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(PlayerItemBreakEvent e) {
        if (weapons.getWeaponId(e.getBrokenItem()) == null) return;
        UUID uuid = e.getPlayer().getUniqueId();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Player p = plugin.getServer().getPlayer(uuid);
            if (p != null && p.isOnline() && progress.isLoaded(uuid)) sync(p);
        });
    }
}

package com.weaponevolution;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Passive effects, on-hit / on-smash abilities and the Sneak + F active abilities. */
public final class AbilityListener implements Listener {

    private final WeaponEvolution plugin;
    private final WeaponManager weapons;
    private final AbilityManager abilities;
    /** Players currently shown a Thunder Strike countdown (so "ready" is announced exactly once). */
    private final Set<UUID> thunderShown = new HashSet<>();

    public AbilityListener(WeaponEvolution plugin, WeaponManager weapons, AbilityManager abilities) {
        this.plugin = plugin;
        this.weapons = weapons;
        this.abilities = abilities;
    }

    // ------------------------------------------------------------------ passives

    public void startPassiveTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                boolean aura = plugin.getConfig().getBoolean("settings.aura-particles", true)
                        && plugin.getConfig().getBoolean("settings.particles", true);
                for (Player p : plugin.getServer().getOnlinePlayers()) {
                    WeaponInfo w = weapons.getInfoFor(p, p.getInventory().getItemInMainHand());
                    if (w == null || w.tier() == Tier.WOODEN) continue; // wooden: nothing
                    abilities.applyPassives(p, w);
                    if (aura && w.tier().aura() != null) {
                        p.getWorld().spawnParticle(w.tier().aura(), p.getLocation().add(0, 1, 0),
                                2, 0.35, 0.6, 0.35, 0.01);
                    }
                }
            }
        }.runTaskTimer(plugin, 10L, 10L);
    }

    // ------------------------------------------------------------------ Thunder Strike countdown

    /**
     * Action-bar countdown for the Beast spear's lightning. It only shows while the player holds their Beast
     * spear and the ability is cooling down, then says "ready" once, so it never spams over other messages.
     * Each player's cooldown is their own (it lives in the AbilityManager, keyed by player UUID).
     */
    public void startThunderDisplayTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                boolean enabled = plugin.getConfig().getBoolean("settings.cooldown-actionbar", true);
                for (Player p : plugin.getServer().getOnlinePlayers()) {
                    UUID id = p.getUniqueId();
                    long left = abilities.remaining(id, Abilities.THUNDER_STRIKE_KEY);
                    if (left <= 0 && !thunderShown.contains(id)) continue;

                    WeaponInfo w = weapons.getInfoFor(p, p.getInventory().getItemInMainHand());
                    boolean holding = enabled && w != null && w.type() == WeaponType.SPEAR && w.tier() == Tier.BEAST;
                    if (!holding) {
                        thunderShown.remove(id);
                        continue;
                    }
                    if (left > 0) {
                        thunderShown.add(id);
                        p.sendActionBar(Component.text("Lightning: " + String.format(Locale.ROOT, "%.1fs", left / 1000.0),
                                NamedTextColor.YELLOW));
                    } else {
                        thunderShown.remove(id); // the cooldown just ended
                        p.sendActionBar(Component.text("Lightning ready", NamedTextColor.GREEN));
                    }
                }
            }
        }.runTaskTimer(plugin, 4L, 4L);
    }

    // ------------------------------------------------------------------ on-hit and on-smash

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;
        if (!(e.getEntity() instanceof LivingEntity victim) || victim == attacker) return;
        if (abilities.isAbilityDamage(attacker)) return; // abilities never trigger from ability damage

        WeaponInfo w = weapons.getInfoFor(attacker, attacker.getInventory().getItemInMainHand());
        if (w == null || w.tier() == Tier.WOODEN) return;

        double damage = e.getFinalDamage();
        boolean shielded = victim instanceof Player vp && vp.isBlocking();
        if (damage <= 0 && !shielded) return;

        double fall = attacker.getFallDistance();
        boolean smash = w.type() == WeaponType.MACE
                && fall > plugin.getConfig().getDouble("settings.smash-min-fall", 1.5)
                && !attacker.isGliding();

        for (Ability a : abilities.unlockedFor(attacker.getUniqueId(), w)) {
            if (a.trigger() == Ability.Trigger.ACTIVE) continue;
            if (a.trigger() == Ability.Trigger.ON_SMASH && !smash) continue;
            if (damage <= 0 && !a.worksWhenBlocked()) continue;

            AbilitySettings s = abilities.settings(a);
            String key = abilities.key(a);
            if (abilities.remaining(attacker.getUniqueId(), key) > 0) continue;
            if (s.chance < 100.0 && ThreadLocalRandom.current().nextDouble() * 100.0 >= s.chance) continue;

            AbilityContext ctx = new AbilityContext(plugin, abilities, attacker, victim, damage, smash, fall, w, s);
            if (a.onHit(ctx)) {
                abilities.startCooldown(attacker.getUniqueId(), key, s.cooldownMs);
            }
        }
    }

    // ------------------------------------------------------------------ active abilities

    @EventHandler(ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        if (!p.isSneaking()) return;

        WeaponInfo w = weapons.getInfoFor(p, p.getInventory().getItemInMainHand());
        if (w == null || w.tier() == Tier.WOODEN) return;

        List<Ability> actives = abilities.unlockedFor(p.getUniqueId(), w).stream()
                .filter(a -> a.trigger() == Ability.Trigger.ACTIVE)
                .toList();
        if (actives.isEmpty()) return;

        e.setCancelled(true);

        Ability waiting = null;
        long shortest = Long.MAX_VALUE;
        for (Ability a : actives) {
            String key = abilities.key(a);
            long left = abilities.remaining(p.getUniqueId(), key);
            if (left > 0) {
                if (left < shortest) {
                    shortest = left;
                    waiting = a;
                }
                continue;
            }
            AbilitySettings s = abilities.settings(a);
            AbilityContext ctx = new AbilityContext(plugin, abilities, p, null, 0, false, p.getFallDistance(), w, s);
            if (a.onActivate(ctx)) {
                abilities.startCooldown(p.getUniqueId(), key, s.cooldownMs);
                if (plugin.getConfig().getBoolean("settings.cooldown-actionbar", true)) {
                    p.sendActionBar(Component.text(a.name().toUpperCase() + "!", NamedTextColor.DARK_RED));
                }
            }
            return;
        }

        if (waiting != null && plugin.getConfig().getBoolean("settings.cooldown-actionbar", true)) {
            long secs = (shortest + 999) / 1000;
            p.sendActionBar(Component.text(waiting.name() + " ready in " + secs + "s", NamedTextColor.RED));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        thunderShown.remove(e.getPlayer().getUniqueId());
        abilities.cleanup(e.getPlayer().getUniqueId());
    }
}

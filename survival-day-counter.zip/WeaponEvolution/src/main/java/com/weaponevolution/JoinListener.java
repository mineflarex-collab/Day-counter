package com.weaponevolution;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;

public final class JoinListener implements Listener {

    private final WeaponEvolution plugin;
    private final DatabaseManager database;

    public JoinListener(WeaponEvolution plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        final UUID uuid = event.getPlayer().getUniqueId();

        // Database work off the main thread.
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            boolean firstTime;
            try {
                firstTime = database.claim(uuid);
            } catch (SQLException e) {
                plugin.getLogger().severe("Database error for " + uuid + ": " + e.getMessage());
                return; // never give items if we can't record it
            }
            if (!firstTime) {
                return;
            }

            // Back to the main thread to touch the inventory.
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                Player player = plugin.getServer().getPlayer(uuid);
                if (player == null || !player.isOnline()) {
                    // Left before delivery: release the claim so they get items next join.
                    plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                        try {
                            database.unclaim(uuid);
                        } catch (SQLException e) {
                            plugin.getLogger().severe("Could not release claim for " + uuid + ": " + e.getMessage());
                        }
                    });
                    return;
                }
                giveStarterWeapons(player);
            });
        });
    }

    private void giveStarterWeapons(Player player) {
        // Plain items: no enchantments, no meta, no custom effects.
        ItemStack spear = new ItemStack(Material.WOODEN_SPEAR, 1);
        ItemStack mace = new ItemStack(Material.MACE, 1);
        // NOTE: see README - vanilla has no "wooden mace"; Mace is the only mace item.

        boolean dropped = false;
        for (ItemStack item : new ItemStack[]{spear, mace}) {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            for (ItemStack left : leftover.values()) {
                player.getWorld().dropItem(player.getLocation(), left);
                dropped = true;
            }
        }

        send(player, plugin.getConfig().getString("welcome-message", ""));
        if (dropped) {
            send(player, plugin.getConfig().getString("inventory-full-message", ""));
        }
    }

    private void send(Player player, String msg) {
        if (msg != null && !msg.isEmpty()) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
        }
    }
}

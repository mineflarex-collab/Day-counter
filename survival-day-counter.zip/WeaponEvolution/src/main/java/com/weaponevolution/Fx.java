package com.weaponevolution;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Locale;

/**
 * A configurable particle + sound pair. Particles and sounds are given as vanilla ids
 * (e.g. "crit", "item.trident.hit"). Use "none" or "" to disable one.
 */
public final class Fx {

    private final WeaponEvolution plugin;
    private final Particle particle;
    private final int count;
    private final double spread;
    private final double speed;
    private final Sound sound;
    private final float volume;
    private final float pitch;

    private Fx(WeaponEvolution plugin, Particle particle, int count, double spread, double speed,
               Sound sound, float volume, float pitch) {
        this.plugin = plugin;
        this.particle = particle;
        this.count = count;
        this.spread = spread;
        this.speed = speed;
        this.sound = sound;
        this.volume = volume;
        this.pitch = pitch;
    }

    /** Reads keys base.<prefix>particle, -count, -spread, -speed, <prefix>sound, -volume, -pitch. */
    public static Fx load(WeaponEvolution plugin, FileConfiguration cfg, String base, String prefix) {
        String p = base + "." + prefix;
        Particle particle = resolveParticle(plugin, cfg.getString(p + "particle"), p + "particle");
        int count = cfg.getInt(p + "particle-count", 10);
        double spread = cfg.getDouble(p + "particle-spread", 0.4);
        double speed = cfg.getDouble(p + "particle-speed", 0.05);
        Sound sound = resolveSound(plugin, cfg.getString(p + "sound"), p + "sound");
        float volume = (float) cfg.getDouble(p + "sound-volume", 1.0);
        float pitch = (float) cfg.getDouble(p + "sound-pitch", 1.0);
        return new Fx(plugin, particle, count, spread, speed, sound, volume, pitch);
    }

    private static boolean blank(String s) {
        return s == null || s.isBlank() || s.equalsIgnoreCase("none");
    }

    private static Particle resolveParticle(WeaponEvolution plugin, String name, String path) {
        if (blank(name)) return null;
        NamespacedKey key = NamespacedKey.fromString(name.trim().toLowerCase(Locale.ROOT));
        Particle found = key == null ? null : Registry.PARTICLE_TYPE.get(key);
        if (found == null) {
            plugin.getLogger().warning("Unknown particle '" + name + "' at " + path + " - ignoring.");
            return null;
        }
        if (found.getDataType() != Void.class) {
            plugin.getLogger().warning("Particle '" + name + "' at " + path
                    + " needs extra data and is not supported - ignoring.");
            return null;
        }
        return found;
    }

    private static Sound resolveSound(WeaponEvolution plugin, String name, String path) {
        if (blank(name)) return null;
        NamespacedKey key = NamespacedKey.fromString(name.trim().toLowerCase(Locale.ROOT));
        Sound found = key == null ? null : Registry.SOUNDS.get(key);
        if (found == null) {
            plugin.getLogger().warning("Unknown sound '" + name + "' at " + path
                    + " (use ids like item.trident.hit) - ignoring.");
        }
        return found;
    }

    public boolean hasParticle() { return particle != null; }

    private boolean particlesOn() { return plugin.getConfig().getBoolean("settings.particles", true); }

    private boolean soundsOn() { return plugin.getConfig().getBoolean("settings.sounds", true); }

    public void particles(Location loc) { particles(loc, count); }

    public void particles(Location loc, int amount) {
        if (particle == null || amount <= 0 || !particlesOn() || loc.getWorld() == null) return;
        loc.getWorld().spawnParticle(particle, loc, amount, spread, spread * 1.2, spread, speed);
    }

    /** A single exact particle (used for rings and lines). */
    public void point(World w, double x, double y, double z) {
        if (particle == null || !particlesOn()) return;
        w.spawnParticle(particle, x, y, z, 1, 0, 0, 0, 0);
    }

    public void sound(Location loc) {
        if (sound == null || !soundsOn() || loc.getWorld() == null) return;
        loc.getWorld().playSound(loc, sound, volume, pitch);
    }

    public void play(Location loc) {
        particles(loc);
        sound(loc);
    }
}
